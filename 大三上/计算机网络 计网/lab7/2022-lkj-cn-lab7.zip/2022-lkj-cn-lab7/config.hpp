#include <arpa/inet.h>
#include <errno.h>
// #include <format>
#include <iostream>
#include <netinet/in.h>
#include <stdio.h>
#include <cstring>
#include <string>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
using namespace std;
const std::string SERVER_IP = "127.0.0.1";
constexpr int SERVER_PORT = 5872;
constexpr int MAX_CONNECTION = 20;
constexpr int BUFFER_SIZE = 1024;
enum serviceId {
  // 以下用"｜"表示多个包之间的分割线
  // 客户端或者服务器可以直接发送一个0，表示断开连接
  // （客户端请求关闭）客户端发送格式 0(size_t大小的数字)
  // 服务器响应格式：6(success)
  // （服务器请求关闭）或者服务器发送: 0 | 字符串长度 | 关闭原因
  disconnect = 0,
  // 客户端可以直接发送一个1，表示需要时间
  // 客户端发送格式 1（size_t大小的数字，也就是0x00000001）
  // 服务器响应格式：6(success) |
  // 时间字符串长度(size_t大小，需要使用strtol函数）| 时间字符串
  getTime,
  // 客户端可以直接发送一个2，表示需要主机名
  // 客户端发送格式 2（size_t大小的数字，也就是0x00000002）
  // 服务器响应格式：6(success) | 主机名长度(size_t大小，需要使用strtol函数）|
  // 主机名字符串
  getName,
  // 客户端可以直接发送一个3，表示需要所有连接客户端的信息
  // 客户端发送格式 3（size_t大小的数字，也就是0x00000003）
  // 服务器响应格式：6(success) | 连接数量(size_t大小，需要使用strtol函数) |
  // 连接列表，列表中每项格式为socket_fd + sockaddr_in
  getAll,
  // 客户端可以直接发送一个4，表示需要服务器转发消息
  // 客户端发送格式 4（size_t大小的数字，也就是0x00000004）｜
  // 需要转发到的socket号 |字符串长度 | 字符串实体
  // 服务器响应格式：6 表示成功，或者 7 表示失败 | 失败原因长度 ｜ 失败原因
  redirect,
  // 只有服务器发送，表示请求无效
  // 服务器发送一个5
  invalidOp,
  // 只有服务器发送，表示成功
  // 服务器发送一个6
  success,
  // 只有服务器发送，表示失败
  // 服务器发送一个7 ｜ 失败原因字符串长度 ｜ 失败原因字符串
  fail,
  // 只有服务器发送，表示服务器转发消息
  // 服务器发送一个8,表示这是转发的消息
  // 服务器发送消息来源端口号 ｜ 消息来源sockaddr_in结构 ｜ 字符串消息长度 |
  // 服务器发送消息字符串
  resend
};
