#include <sstream>
#include "client.h"

void Client::run() {
    while(run_) {
        o_lock_.lock();
        cout << "\033[32mclient shell > \033[0m";
        got_input_ = false;
        o_lock_.unlock();
        string input;
        getline(cin, input);
        got_input_ = true;
        if (input.length()==0) {
            continue;
        }
        
        auto command = parse(input);
        execute(command); 
    }
}

vector<string> Client::parse(const string &command) {
    stringstream ss(command);
    string tmp;
    vector<string> res;
    while (ss >> tmp) {
        res.push_back(tmp);
    }
    return move(res);
}

void Client::execute(vector<string> &command) {
    if(command[0] == "connect") {
        if(command.size() != 3) {
            cout << "\033[31mERROR :\033[0m connect command shall have exactly 2 args." << endl;
            return;
        }
        stringstream ss(command[2]);
        int port;
        ss >> port;
        con(command[1], port);
    }

    else if(command[0] == "disconnect") {
        if (connected_ == false) {
            o_lock_.lock();
            cout << "you are not in connection now." << endl;
            o_lock_.unlock();
        }
        
        int service_id = serviceId::disconnect;
        send(client_socket_, &service_id, sizeof(int), 0);
    }

    else if (command[0] == "time")
        get_time();
    
    else if (command[0] == "name")
        get_name();
    
    else if (command[0] == "all")
        get_all();

    else if (command[0] == "redirect") {
        if (command.size() < 3) {
            o_lock_.lock();
            cout << "\033[31mERROR :\033[0m redirect command receive 2 args" 
                 << endl
                 << "        args 0: the socket num"
                 << endl
                 << "        args 1: the message"
                 << endl;
            o_lock_.unlock();
            return;
        }
        else 
        redirect(command);
    }

    else if (command[0] == "time")
        get_time();

    else if(command[0] == "exit") {
        run_ = false;
        discon();
    }
    
    else if (command[0] == "help")
        system("cat help.txt");
        
    else {
        o_lock_.lock();
        cout << "\033[31mInvalid command.\033[0m" << endl;
        o_lock_.unlock();
    }
}
    
void Client::con(string ip, int port) {
    if (connected_ == true) {
        o_lock_.lock();
        cout << "you have got connection." << endl;
        o_lock_.unlock();
        return;
    }
    client_socket_ = socket(AF_INET, SOCK_STREAM, 0);
    if (client_socket_ == -1) {
        o_lock_.lock();
        cout << "met error when making socket word" << endl;
        o_lock_.unlock();
    }

    server_addr_.sin_port = htons(port);
    server_addr_.sin_family = AF_INET;
    server_addr_.sin_addr.s_addr = inet_addr(ip.c_str());
    if (server_addr_.sin_addr.s_addr == -1) {
        o_lock_.lock();
        cout << "\033[31mInvalid\033[0m ip address " << ip << endl;
        o_lock_.unlock();
        return;
    }
    
    
    int succ = connect(client_socket_, (sockaddr *)&server_addr_, sizeof(sockaddr));
    
    if(succ == -1) {
        o_lock_.lock();
        cout << "Fail to connect. Please check if the ip address "
             << ip
             <<" is correct, otherwise the current server is busy."
             << endl;
        o_lock_.unlock();
        return;
    }
    
    
    connected_ = true;
    thread t(&Client::receive_loop_, this);
    receive_thread_ = move(t);
}

void Client::discon() {
    if (connected_ == false) {
        return;
    }
    
    connected_ = false;
    close(client_socket_);
    receive_thread_.join();
}

void Client::get_name() {
    if (!connected_) {
        o_lock_.lock();
        cout << "Please connect to the server first. Try `connect`" << endl;
        o_lock_.unlock();
        return;
    }
    int service_id = serviceId::getName;
    send(client_socket_, &service_id, sizeof(int), 0);
}

void Client::get_all() {
    if (!connected_) {
        o_lock_.lock();
        cout << "Please connect to the server first. Try `connect`" << endl;
        o_lock_.unlock();
        return;
    }
    int service_id = serviceId::getAll;
    send(client_socket_, &service_id, sizeof(int), 0);
    get_all_ = true;
};

void Client::get_time() {
    if (!connected_) {
        o_lock_.lock();
        cout << "Please connect to the server first. Try `connect`" << endl;
        o_lock_.unlock();
        return;
    }
    int service_id = serviceId::getTime;
    send(client_socket_, &service_id, sizeof(int), 0);
};

void Client::redirect(vector<string> msg) {
    if (!connected_) {
        o_lock_.lock();
        cout << "Please connect to the server first. Try `connect`" << endl;
        o_lock_.unlock();
        return;
    }
    stringstream ss(msg[1]);
    int sock_id;
    ss >> sock_id;
    int len = msg[2].length();
    int service_id = serviceId::redirect;
    send(client_socket_, &service_id, sizeof(int), 0);
    send(client_socket_, &sock_id, sizeof(int), 0);
    send(client_socket_, &len, sizeof(int), 0);
    send(client_socket_, msg[2].c_str(), len, 0);
}

void Client::receive_loop_() {
    for(;;) {
        char buffer[1024] = {0};
        int service_type;
        int received = recv(client_socket_, &service_type, sizeof(int), 0);
        if(received == -1) break;
        Message msg{Message::MessageType::INVALID, {}};
        switch(service_type) {
            case serviceId::disconnect : {
                int len = 0;
                recv(client_socket_, &len, sizeof(int), 0);
                memset(buffer, 0, 1024);
                recv(client_socket_, buffer, len%1024, 0);
                msg = {Message::MessageType::DISCONN, {buffer}};
                break;
            }
            
            case serviceId::getTime : {
                int len = 0;
                recv(client_socket_, &len, sizeof(int), 0);
                memset(buffer, 0, 1024);
                recv(client_socket_, buffer, len%1024, 0);
                msg = {Message::MessageType::TIME, {buffer}};
                break;
            }

            case serviceId::getName : {
                int len = 0;
                recv(client_socket_, &len, sizeof(int), 0);
                memset(buffer, 0, 1024);
                recv(client_socket_, buffer, len%1024, 0);
                msg = {Message::MessageType::NAME, {buffer}};
                break;
            }

            case serviceId::fail : {
                int len = 0;
                recv(client_socket_, &len, sizeof(int), 0);
                memset(buffer, 0, 1024);
                recv(client_socket_, buffer, len%1024, 0);
                msg = {Message::MessageType::ERROE, {buffer}};
                break;
            }

            case serviceId::getAll : {
                SOCKET sock_id = 0, self_sock_id = 0;
                sockaddr_in sock_addr;
                recv(client_socket_, &self_sock_id, sizeof(uint32_t), 0);
                int size = 0;
                recv(client_socket_, &size, sizeof(int), 0);
                vector<string> tmp;
                tmp.reserve(size);
                for (size_t i = 0; i < size; i++) {
                    recv(client_socket_, &sock_id, sizeof(uint32_t), 0);
                    recv(client_socket_, &sock_addr, sizeof(sock_addr), 0);
                    if (sock_id != self_sock_id)
                    {
                        char sock[20];
                        sprintf(sock, "%5u", sock_id);
                        tmp.push_back(sock);
                        tmp.push_back(inet_ntoa(sock_addr.sin_addr));
                    }
                }
                msg = {Message::MessageType::ALL, tmp};
                break;
            }

            case serviceId::resend : {
                int message_num;
                recv(client_socket_, &message_num, sizeof(int), 0);
                vector<string> tmp;
                tmp.reserve(3 * message_num);
                for (size_t i = 0; i < message_num; i++) {
                    SOCKET sock_id;
                    sockaddr_in sock_addr;
                
                    recv(client_socket_, &sock_id, sizeof(int), 0);
                    recv(client_socket_, &sock_addr, sizeof(sock_addr), 0);
                    char sock[30];
                    sprintf(sock, "%5u", sock_id);
                    tmp.push_back(sock);
                    tmp.push_back(inet_ntoa(sock_addr.sin_addr));
                    int len;
                    recv(client_socket_, &len, sizeof(len), 0);
                    memset(buffer, 0, 1024);
                    recv(client_socket_, buffer, len%1024, 0);
                    tmp.push_back(buffer);
                }
                msg = {Message::MessageType::RESEND, tmp};
                break;
            }

            case serviceId::redirect : {
                msg = {Message::MessageType::REDRICT, {}};
                break;
            }
        }
        o_lock_.lock();
        if (!got_input_) cout << endl;
        cout << msg;
        if (!got_input_) cout << "\033[32mclient shell > \033[0m";
        o_lock_.unlock();
    }
};

ostream &operator<<(ostream &output, const Message &message_) {
    switch (message_.type_) {
    case Message::MessageType::TIME :
        output << "\033[34mserver time: \033[0m" << message_.message_[0] <<endl;
        break;
    case Message::MessageType::NAME :
        output << "\033[34mserver name: \033[0m" << message_.message_[0] <<endl;
        break;
    case Message::MessageType::REDRICT :
        output << "\033[34mSuccess to redirect message.\033[0m" << endl;
        break;
    case Message::MessageType::DISCONN :
        output << "\033[34mGet disconnect signal from server.\033[0m"
               << endl
               << "Reason: "
               << message_.message_[0]
               << endl;
        break;
    case Message::MessageType::ERROE :
        output << "\033[31mFail: \033[0m" <<message_.message_[0] << endl;
        break;
    case Message::MessageType::RESEND : {
        output << "\033[34mGet \033[0m" << (int)(message_.message_.size()/3) << " messages:" << endl;
        for (size_t i = 0; i < message_.message_.size(); i+=3) {
            output << "Message from sock_id "
               << message_.message_[i]
               << " ip "
               << message_.message_[i+1]
               << " :\n"
               << message_.message_[i+2]
               << endl;
        }
        break;   
    }
    case Message::MessageType::ALL : {
        output << "\033[34mall users:\033[0m" << endl << " socked_id | ip" << endl;
        for (size_t i = 0; i < message_.message_.size(); i+=2) {
            output << message_.message_[i] << " " << message_.message_[i+1] << endl;
        }
        break;
    }
    default:
        break;
    }
    return output;
}