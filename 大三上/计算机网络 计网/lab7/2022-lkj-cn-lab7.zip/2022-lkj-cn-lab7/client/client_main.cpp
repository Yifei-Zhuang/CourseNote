#include "client.h"
int main()
{
    Client client;
    client.run();
    return 0;
}