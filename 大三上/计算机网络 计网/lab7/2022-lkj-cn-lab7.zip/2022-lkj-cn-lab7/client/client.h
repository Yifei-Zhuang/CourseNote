#include "../config.hpp"
#include <mutex>
#include <vector>
#include <thread>
#include <queue>
#include <sys/socket.h> 
#include <netinet/in.h>
#include <atomic>
class Message {
public:
    enum class MessageType { INVALID, TIME, NAME, ALL, ERROE, DISCONN, RESEND, REDRICT };
public:
    Message (MessageType type, vector<string> message) : type_(type), message_(move(message)) {}
    friend ostream &operator<<(ostream &output, const Message &message_);
private:
    MessageType type_;
    vector<string> message_;
};

class Client
{
    using SOCKET = uint32_t;
public:
    void run();

private:
    bool connected_ = false;
    bool run_ = true;
    bool get_all_ = false;
    SOCKET client_socket_;
    sockaddr_in server_addr_;
    thread receive_thread_;
    mutex o_lock_;
    atomic<bool> got_input_{false};

    vector<string> parse(const string &command);
    void execute(vector<string> &command);

    void con(string ip, int port);
    void redirect(vector<string> msg);
    void discon();
    void get_time();
    void get_name();
    void get_all();
    void receive_loop_();
};