
#include "ThreadPool.hpp"
#include <string>

bool ThreadPool::stop = false;
unordered_map<int, Connection *> ThreadPool::tpmap;
mutex ThreadPool::tp_lock;
Connection::Connection(string &ip, int port) {
  this->ip = ip;
  this->port = port;
}
void Connection::pop() {
  lock.lock();
  msg_queue.pop_front();
  lock.unlock();
}
void Connection::push(socketID id, string &in, sockaddr_in &sock) {
  lock.lock();
  msg_queue.emplace_back(id, in, forward<sockaddr_in>(sock));
  lock.unlock();
}
const string &Connection::getIp() const { return ip; }
int Connection::getPort() const { return port; }
auto Connection::resendAllMsg(int sockfd) -> void {
  if (!empty()) {
    // 有消息
    //先发送一个opcode
    int opcode = resend;
    send(sockfd, &opcode, sizeof(opcode), 0);
    uint32_t count = getMsgSize();
    send(sockfd, &count, sizeof(count), 0);
    // 然后将消息队列中的消息全部转发
    while (!empty()) {
      // 这里不能上锁
      auto [sockid, msg, origin] = top();
      pop();
      // 发送来源的socket号
      send(sockfd, &sockid, sizeof(sockid), 0);
      // 发送来源的sockaddr_in结构
      send(sockfd, &origin, sizeof(sockaddr_in), 0);
      uint32_t msg_len = msg.size();
      //发送字符串长度
      send(sockfd, &msg_len, sizeof(uint32_t), 0);
      // 发送字符串本体
      send(sockfd, msg.c_str(), msg_len, 0);
    }
  }
}
void ThreadPool::push(string clientIP, int clientPort, int sockfd) {
  tp_lock.lock();
  auto temp = new Connection(clientIP, clientPort);
  tpmap.emplace(sockfd, temp);
  tp_lock.unlock();
  pthread_t thread_id;
  args a;
  a.c = tpmap[sockfd];
  a.sockfd = sockfd;
  cout << "\033[32;4m[connect]\033[0m " << clientIP << ":" << clientPort << "  conected"
       << "sockid is " << sockfd << endl;
  pthread_create(&thread_id, nullptr, loop, &a);
  tpmap.find(sockfd)->second->setThreadID(thread_id);
}
void *ThreadPool::loop(void *a) {
  Connection *c = ((args *)(a))->c;
  int sockfd = ((args *)a)->sockfd;
  for (;;) {
    try {
      if (stop) {
        // 线程需要停止
        // 向客户端发送信息
        // 将消息队列中的消息全部转发
        auto connection = tpmap.find(sockfd);
        connection->second->resendAllMsg(sockfd);
        string msg = "disconnect since server shut down";
        int opcode = 0;
        send(sockfd, &opcode, sizeof(opcode), 0);
        uint32_t len = msg.size();
        send(sockfd, &len, sizeof(len), 0);
        send(sockfd, msg.c_str(), msg.size(), 0);
        close(sockfd);
        return nullptr;
      }
      char buffer[BUFFER_SIZE] = {0};
      int opcode = 10;
      uint32_t len = recv(sockfd, &opcode, sizeof(serviceId), 0);
      if (len > 0) {
        // invalidOp 以及 success只有服务器可以发送给客户端
        if (opcode < 0 || opcode > redirect) {
          // 无效服务代码
          int s = invalidOp;
          send(sockfd, &s, sizeof(s), 0);
          continue;
        }
        switch (opcode) {
        case disconnect: {
          //客户端要求关闭连接
          //加锁
        dis:
          tp_lock.lock();
          //关闭套接字，回收资源
          close(sockfd);
          if (tpmap[sockfd])
          {
            delete tpmap[sockfd];
            tpmap.erase(sockfd);
          }
          tp_lock.unlock();
          int serviceid = 6; // 成功关闭连接
          send(sockfd, &serviceid, sizeof(serviceid), 0);
          cout << "\033[34;4m[disconnect]\033[0m disconnect with " << sockfd << endl;
          return nullptr;
        }
        case getTime: {
          // int serviceId = success;
          int serviceId = getTime;
          time_t ts = time(nullptr);
          char temp[32]{0};
          strncpy(temp, ctime(&ts), sizeof(temp));
          send(sockfd, &serviceId, sizeof(serviceId), 0);
          uint32_t timeLen = strlen(temp);
          send(sockfd, &timeLen, sizeof(timeLen), 0);
          send(sockfd, temp, timeLen, 0);
          cout << "\033[36;4m[service]\033[0m getTime from " << sockfd << endl;
          break;
        }

        case getName: {
          char nameBuffer[BUFFER_SIZE];
          gethostname(nameBuffer, BUFFER_SIZE);
          // int serviceId = success;
          int serviceId = getName;
          send(sockfd, &serviceId, sizeof(serviceId), 0);
          uint32_t bufferLen = strlen(nameBuffer);
          send(sockfd, &bufferLen, sizeof(bufferLen), 0);
          send(sockfd, nameBuffer, bufferLen, 0);
          cout << "\033[36;4m[service]\033[0m getName from " << sockfd << "string is "
               << nameBuffer << "len is " << bufferLen << endl;
          break;
        }
        case getAll: {
          // 要求获取所有连接终端的信息
          // 首先发送一个success
          // int serviceId = success;
          int serviceId = getAll;
          cout << "\033[36;4m[service]\033[0m getAll from " << sockfd << endl;
          send(sockfd, &serviceId, sizeof(serviceId), 0);
          // 上锁
          tp_lock.lock();
          // 发送当前连接号
          send(sockfd,&sockfd,sizeof(uint32_t),0);
          // 然后发送一共有多少个连接
          uint32_t count = tpmap.size();
          send(sockfd, &count, sizeof(count), 0);
          // 然后遍历所有连接，发送信息
          for (auto &[sockid, connection] : tpmap) {
            // 先发送一个sockid
            send(sockfd, &sockid, sizeof(sockid), 0);
            // 然后发送一个socketaddr_in
            sockaddr_in tempAddr_in{};
            tempAddr_in.sin_family = AF_INET;
            tempAddr_in.sin_port = connection->getPort();
            tempAddr_in.sin_addr.s_addr =
                inet_addr(connection->getIp().c_str());
            // tempAddr_in.sin_len = 16;
            send(sockfd, &tempAddr_in, sizeof(sockaddr_in), 0);
          }
          tp_lock.unlock();
          break;
        }

        case redirect: {
          // 接收到一个消息
          // 首先接收目标socketid
          int sockid;
          recv(sockfd, &sockid, sizeof(sockfd), 0);
          //          char *unused;
          //          sockid = static_cast<int>(strtol(buffer, &unused, 10));
          tp_lock.lock();
          auto temp = tpmap.find(sockid);
          // 查找是否有该socket
          // 接收字符串长度
          uint32_t len;
          recv(sockfd, &len, sizeof(uint32_t), 0);
          //          len = strtol(buffer, &unused, 10);
          // 然后接收字符串
          recv(sockfd, buffer, len, 0);
          buffer[len] = '\0';
          cout << "\033[36;4m[service]\033[0m redirect from " << sockfd << " to " << sockid
               << " msg is " << buffer << endl;
          if (temp == tpmap.end()) {
            tp_lock.unlock();
            // fail
            int serviceid = fail;
            send(sockfd, &serviceid, sizeof(fail), 0);
            string fail_reason = "cannot find this connection, please check";
            int len = fail_reason.size();
            send(sockfd, &len, sizeof(len), 0);
            send(sockfd, fail_reason.c_str(), len, 0);
            continue;
          }
          auto connection = tpmap[sockid];
          string msg(buffer);
          sockaddr_in tempAddr_in{};
          tempAddr_in.sin_family = AF_INET;
          tempAddr_in.sin_port = c->getPort();
          tempAddr_in.sin_addr.s_addr = inet_addr(c->getIp().c_str());
          tempAddr_in.sin_len = 16;
          connection->push(sockfd, msg, tempAddr_in);
          tp_lock.unlock();
          // 发送成功
          int suc = redirect;
          send(sockfd, &suc, sizeof(suc), 0);
          break;
        }
        default: {
          cout << "\033[31;4m[exception]\033[0m invalid operation code from " << sockfd << endl;
          serviceId s = invalidOp;
          send(sockfd, &s, sizeof(uint32_t), 0);
          break;
        }
        }
      } else if (len <= 0) {
        // 空的无效消息
        cout << "receive empty msg from " << c->getIp() << ":" << c->getPort()
             << endl;
        // 断开连接
        goto dis;
      }
      // 检查消息队列中有无消息
      auto connection = tpmap.find(sockfd);
      if (connection != tpmap.end()) {
        connection->second->resendAllMsg(sockfd);
      }
    } catch (std::exception &e) {
      // 发生错误，关闭连接
      string msg = "server error, disconect";
      int opcode = 0;
      send(sockfd, &opcode, sizeof(opcode), 0);
      uint32_t len = msg.size();
      send(sockfd, &len, sizeof(len), 0);
      send(sockfd, msg.c_str(), msg.size(), 0);
      close(sockfd);
      return nullptr;
    }
  }
}
ThreadPool::~ThreadPool() {
  // 向子线程发送信号
  stop = true;
  tp_lock.lock();
  for (auto &[sockId, c] : tpmap) {
    pthread_t thread_id = c->getThreadId();
    pthread_join(thread_id, nullptr);
    delete c;
    tpmap.erase(sockId);
  }
  tp_lock.unlock();
}
