#pragma once
#include "../config.hpp"
#include <mutex>
#include <queue>
#include <thread>
#include <unordered_map>

class Connection {
private:
  using socketID = int;
  string ip;
  int port;
  pthread_t thread_id;
  // 为消息队列上锁
  mutex lock;
  // 线程的消息队列
  deque<tuple<socketID, string, sockaddr_in>> msg_queue;

public:
  inline mutex &getLock() { return lock; }
  Connection(string &ip, int port);
  const string &getIp() const;
  int getPort() const;
  inline pthread_t getThreadId() const { return thread_id; }
  inline void setThreadID(pthread_t t) { this->thread_id = t; }
  void push(socketID, string &, sockaddr_in &);
  inline tuple<socketID, string, sockaddr_in> top() {
    return msg_queue.front();
  }
  void pop();
  bool empty() { return msg_queue.empty(); }
  size_t getMsgSize() { return msg_queue.size(); }
  void resendAllMsg(int sockfd);
};
class ThreadPool {
private:
  static bool stop;
  // tpmap的锁
  static mutex tp_lock;
  // map from sockid to thread id
  static unordered_map<int, Connection *> tpmap;

public:
  class args {
  public:
    Connection *c;
    int sockfd;
    args() = default;
  };
  ThreadPool() = default;
  ~ThreadPool();

  static void *loop(void *a);
  static void push(string clientIP, int clientPort, int sockfd);
};
