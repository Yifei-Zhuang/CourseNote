#include "ThreadPool.hpp"
int main() {

  ThreadPool t;
  // 客户端套接字
  int sockfd;
  // 创建服务端套接字
  sockfd = socket(AF_INET, SOCK_STREAM, 0);
  // 服务器IP地址以及客户端IP地址
  struct sockaddr_in serverAddr;
  bzero(&serverAddr, sizeof(serverAddr));
  serverAddr.sin_family = AF_INET;
  serverAddr.sin_port = htons(SERVER_PORT);
  serverAddr.sin_addr.s_addr = htonl(INADDR_ANY);

  //  inet_pton(AF_INET, SERVER_IP.c_str(), &serverAddr.sin_addr.s_addr);
  if (::bind(sockfd, (struct sockaddr *)&serverAddr, sizeof(struct sockaddr)) ==
      -1) {
    cout << "bind socket failed!" << errno << std::endl;
    exit(1);
  }
  if (listen(sockfd, MAX_CONNECTION) == -1) {
    cout << "listen port " << SERVER_PORT << " failed!" << endl;
    exit(1);
  }
  cout << "listening on port " << SERVER_PORT << endl;
  int client_fd;
  struct sockaddr_in clientAddr;
  try {
    for (;;) {
      socklen_t client_len = sizeof(struct sockaddr_in);
      if ((client_fd = accept(sockfd, (struct sockaddr *)&clientAddr,
                              &client_len)) == 0) {
        cout << "accept req failed! " << errno << endl;
        continue;
      }
      // buffer for client ip
      char buffer[BUFFER_SIZE];
      if (inet_ntop(AF_INET, &clientAddr.sin_addr.s_addr, buffer,
                    sizeof(buffer)) == 0) {
        cout << "invalid client ip!" << errno << endl;
        continue;
      }
      auto port = ntohs(clientAddr.sin_port);
      t.push(buffer, port, client_fd);
    }
  } catch (std::exception &e) {
    close(sockfd);
    // main();
  }
  return 0;
}