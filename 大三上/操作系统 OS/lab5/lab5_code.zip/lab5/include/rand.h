#include "types.h"

#define SEED 13
unsigned long rand();
