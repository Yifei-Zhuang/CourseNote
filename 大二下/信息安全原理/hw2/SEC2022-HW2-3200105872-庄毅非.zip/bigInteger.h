#include <algorithm>
#include <iostream>
#include <vector>
using namespace std;

vector<int> input1;
int length1;
vector<int> input2;
int length2;