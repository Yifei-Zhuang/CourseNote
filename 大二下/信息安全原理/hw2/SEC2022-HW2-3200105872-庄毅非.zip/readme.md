SEC2022-HW2
usage: run `make ` in this directory.The output file `./bigInteger` is for task1, `./DH` is for task 2 
