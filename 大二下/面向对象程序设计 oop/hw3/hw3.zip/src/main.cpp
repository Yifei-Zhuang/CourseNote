#include "game.cpp"

int main()
{
    Game game;
    game.play();
    return 0;
}