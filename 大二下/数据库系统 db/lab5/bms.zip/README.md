#BMS 2022
用法：进入后端目录，按照其中的Readme.md指示启动后端，随后进入前端目录按照其中的Readme.md启动前端，之后在浏览器中访问http://localhost:3000即可查看管理系统
