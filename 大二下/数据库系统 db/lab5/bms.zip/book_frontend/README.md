# Book Management System 2022
Author: 软工2002 庄毅非 3200105872
usage: Make sure the backend is running, then run `yarn install;yarn dev` in this directory, wait for it to compile and then visit localhost:3000 in your browser to view BMS; 