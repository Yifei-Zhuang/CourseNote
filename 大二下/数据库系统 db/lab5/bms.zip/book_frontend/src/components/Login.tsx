import * as React from 'react';
import Avatar from '@mui/material/Avatar';
import Button from '@mui/material/Button';
import CssBaseline from '@mui/material/CssBaseline';
import TextField from '@mui/material/TextField';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import Link from '@mui/material/Link';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import theme from '../theme'
import axios from 'axios';
import { truncateSync } from 'fs';
import { NextResponse } from 'next/server';
const baseUrl = "http://localhost:9000"
const sideBarWidth: number = 250;

export default function SignIn() {
    const [isFirst, setIsFirst] = React.useState(0);
    const userNameRef = React.useRef<any>('');
    const passwordRef = React.useRef<any>('');
    const [isLoginFail, setIsLoginFail] = React.useState(false);
    const [helperText, setHelperText] = React.useState('' as String);
    const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        const userInfo = {
            "username": userNameRef.current!.value,
            "password": passwordRef.current!.value,
        };
        // console.log(userInfo);
        const logInUrl = `${baseUrl}/api/auth/login`;
        axios({
            method: 'POST',
            url: logInUrl,
            data: userInfo,
            withCredentials: true,
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        }).then(res => {
            // console.log(res)
            setIsFirst(0);
            setIsLoginFail(false);
            setHelperText("")
        }).catch(err => {
            if (err !== undefined) {
                console.error(err);
                setIsLoginFail(true)
                if (typeof (err.response) != "undefined")
                    setHelperText(err.response.data.error)
            }
        }).finally(() => {
            setIsFirst(1)
        })
    };
    return (
        <Box sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center"
        }}>
            <CssBaseline />
            <Box
                sx={{
                    marginTop: 8,
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                }}
            >
                <Avatar sx={{ m: 1, bgcolor: "rgb(238,130,238)", color: "white" }}>
                    <Link href="/">
                        <LockOutlinedIcon />
                    </Link>
                </Avatar>
                <Typography component="h1" variant="h5">
                    {
                        <Box>登陆</Box>
                    }
                </Typography>
                <Box component="form" onSubmit={handleSubmit} noValidate sx={{ mt: 1 }}>
                    <TextField
                        margin="normal"
                        required
                        fullWidth
                        id="username"
                        label="username"
                        name="username"
                        autoComplete="username"
                        autoFocus
                        inputRef={userNameRef}
                        error={isLoginFail}
                    />
                    <TextField
                        margin="normal"
                        required
                        fullWidth
                        name="password"
                        label="Password"
                        type="password"
                        id="password"
                        autoComplete="current-password"
                        inputRef={passwordRef}
                        error={isLoginFail}
                        helperText={isLoginFail ? "invalid username or password inputed" : ""}
                    />

                    <Button
                        type="submit"
                        fullWidth
                        color={
                            isFirst == 0 ? "primary" : (isLoginFail ? "error" : "success")
                        }
                        variant="contained"
                        sx={{ mt: 3, mb: 2 }}
                    >
                        {
                            isFirst == 0 ?
                                <Box>登陆</Box>
                                : (!isLoginFail ? <Box>登陆成功!</Box> : <>登陆失败</>)
                        }
                    </Button>
                    <Grid container>
                        <Grid item>
                            <Link href="/register" variant="body2">
                                {"没有账号？在这里注册"}
                            </Link>
                        </Grid>
                    </Grid>
                </Box>
            </Box>
        </Box>
    );
}