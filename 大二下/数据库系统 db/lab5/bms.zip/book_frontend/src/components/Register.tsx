import { ThemeProvider } from '@emotion/react';
import { Avatar, Container, TextField, Typography } from '@mui/material';
import * as React from 'react';
import { Box } from '@mui/system';
import theme from '../theme'
import Link from 'next/link';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import { Button } from '@mui/material';
import axios from 'axios';
const baseUrl = "http://localhost:9000"
const RegisterBox: React.FC = () => {
    const [isFirst, setIsFirst] = React.useState(0);
    const userNameRef = React.useRef<any>('' as String)
    const passwordRef = React.useRef<any>('' as String)
    const [isRegisterFailed, setIsRegisterFailed] = React.useState(false);
    const [helperText, setHelperText] = React.useState('' as String);
    const Register = (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        const registerUrl = `${baseUrl}/api/auth/register`
        const userInfo = {
            "username": userNameRef.current!.value,
            "password": passwordRef.current!.value
        }
        axios({
            method: "POST",
            url: registerUrl,
            data: userInfo,
            withCredentials: true,
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        }).then(() => {
            setIsRegisterFailed(false)
            setHelperText("")
        }
        ).catch((err) => {
            setIsRegisterFailed(true)
            if (typeof (err.response) != "undefined")
                setHelperText(err.response.data.error)
        }).finally(() => {
            setIsFirst(1)
        })
    }
    return (
        <ThemeProvider theme={theme} >
            <Box component="main" sx={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center"
            }}>
                <Container sx={{
                    marginTop: 8,
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                }}>
                    <Avatar sx={{ m: 1, bgcolor: "rgb(238,130,238)" }}>
                        <Link href="/">
                            <LockOutlinedIcon />
                        </Link>
                    </Avatar>
                    <Typography component="h1" variant="h5">
                        {
                            <Box>注册</Box>
                        }
                    </Typography>
                    <Box component="form" onSubmit={Register} noValidate sx={{ mt: 1 }}>
                        <TextField
                            margin="normal"
                            required
                            fullWidth
                            id="username"
                            label="username"
                            name="username"
                            autoComplete="username"
                            autoFocus
                            inputRef={userNameRef}
                            error={isRegisterFailed}
                            helperText={isRegisterFailed ? helperText : ""}
                        />
                        <TextField
                            margin="normal"
                            required
                            fullWidth
                            name="password"
                            label="Password"
                            type="password"
                            id="password"
                            autoComplete="current-password"
                            inputRef={passwordRef}
                            error={isRegisterFailed}
                            helperText={isRegisterFailed ? helperText : ""}
                        />
                        <Button type="submit"
                            variant="contained"
                            sx={{ mt: 3, mb: 2 }}
                            fullWidth
                            color={
                                isFirst == 0 ? "primary" : (isRegisterFailed ? "error" : "success")
                            }
                        >
                            {
                                isFirst == 0 ?
                                    <Box>注册</Box>
                                    : (!isRegisterFailed ? <Box>注册成功</Box> : <>注册失败</>)
                            }
                        </Button>
                    </Box>

                </Container>
            </Box>
        </ThemeProvider>
    )
}


export default RegisterBox;