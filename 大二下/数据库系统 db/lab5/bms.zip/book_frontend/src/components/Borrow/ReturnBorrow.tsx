import { ThemeProvider } from '@emotion/react'
import * as React from 'react'
import theme from '../../theme'
import { Container } from '@mui/material'
import { Box } from '@mui/material'
import { CssBaseline } from '@mui/material'
import { Typography } from '@mui/material'
import { TextField } from '@mui/material'
import { Button } from '@mui/material'
import axios from 'axios'
const baseUrl = "http://localhost:9000"
const ReturnBorrow = () => {
    const [isFirst, setIsFirst] = React.useState(0);
    const cnoRef = React.useRef<any>('')
    const bnoRef = React.useRef<any>('')
    const [error, setError] = React.useState(false);
    const [helperText, setHelperText] = React.useState("")

    React.useEffect(() => {
        setError(false);
    }, [])
    const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        const returnBookUrl = `${baseUrl}/api/borrow/returnBorrow`
        axios({
            url: returnBookUrl,
            method: "POST",
            withCredentials: true,
            headers: {
                "Content-Type": "application/json"
            },
            data: {
                "cno": cnoRef.current.value,
                "bno": bnoRef.current.value
            }
        }).then(res => {
            // console.log(res)
            setError(false);
            setHelperText("")

        }).catch(err => {
            console.error(err)
            setError(true)
            setHelperText(err.response.data.error)
        }).finally(() => {
            setIsFirst(1)
        })
    }
    return (
        <ThemeProvider theme={theme}>
            <Container>
                <CssBaseline />
                <Box sx={{
                    marginTop: 8,
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                }}>
                    <Box component="form" onSubmit={handleSubmit} noValidate sx={{
                        width: "100%"
                    }}>
                        <Typography
                            component='h1'
                            variant='subtitle1'
                            align='center'
                        >
                            输入cno和bno进行书籍归还~
                        </Typography>
                        <TextField
                            inputRef={cnoRef}
                            required
                            id="outlined-required"
                            label="cno"
                            autoFocus
                            fullWidth
                            name="cno"
                            autoComplete='cno'
                            sx={{
                                mt: "10px"
                            }}
                            error={error}
                            helperText={helperText}
                        />
                        <TextField
                            inputRef={bnoRef}
                            required
                            id="outlined-required"
                            label="bno"
                            autoFocus
                            fullWidth
                            name="bno"
                            autoComplete='bno'
                            sx={{
                                mt: "10px"
                            }}
                            error={error}
                            helperText={helperText}
                        />
                        <Button
                            type="submit"
                            fullWidth
                            variant="contained"
                            sx={{ mt: 3, mb: 2 }}
                            color={
                                isFirst == 0 ? "primary" : (error ? "error" : "success")
                            }
                        >
                            {
                                isFirst == 0 ?
                                    <Box>还书</Box>
                                    : (!error ? <Box>还书成功！</Box> : <>还书失败</>)
                            }
                        </Button>
                    </Box>
                </Box>
            </Container>
        </ThemeProvider>
    )
}

export default ReturnBorrow;