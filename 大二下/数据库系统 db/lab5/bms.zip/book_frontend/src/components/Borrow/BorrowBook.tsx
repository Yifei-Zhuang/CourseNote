import { ThemeProvider } from '@emotion/react'
import * as React from 'react'
import theme from '../../theme'
import { Container } from '@mui/material'
import { Box } from '@mui/material'
import { CssBaseline } from '@mui/material'
import { Typography } from '@mui/material'
import { TextField } from '@mui/material'
import { Button } from '@mui/material'
import BorrowList from '../Card/BorrowList'
import axios from 'axios'
import type { borrow } from '../Book/DisplayAllBook'
import type { book } from '../Book/Booklist'
const baseUrl = "http://localhost:9000"
const BorrowBook = () => {
    const cnoRef = React.useRef<any>('')
    const bnoRef = React.useRef<any>('')
    const [hasBook, setHasBook] = React.useState(true)
    const [bookList, setBookList] = React.useState([] as borrow[])
    const [isFirst, setIsFirst] = React.useState(0);
    const [isQueryFail, setIsQueryFail] = React.useState(false);
    const [helperText, setHelperText] = React.useState('' as String);

    React.useEffect(() => {
        setHasBook(true)
        setBookList([])
    }, [])
    const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        const addBorrowUrl = `${baseUrl}/api/borrow/borrowBook`
        axios({
            url: addBorrowUrl,
            method: "POST",
            withCredentials: true,
            headers: {
                "Content-Type": "application/json"
            },
            data: {
                "cno": cnoRef.current.value,
                "bno": bnoRef.current.value
            }
        }).then(res => {
            // console.log(res)
            setHasBook(true)
            setIsQueryFail(false)
            setHelperText("")
        }).catch(err => {
            if (err.request) {
                setHasBook(false); setBookList([err.response.data.books as borrow])
            }
            setIsQueryFail(true)
            setHelperText(err.response.data.error)
        }).finally(() => {
            setIsFirst(1)
        })
    }
    return (
        <ThemeProvider theme={theme}>
            <Container>
                <CssBaseline />
                <Box sx={{
                    marginTop: 8,
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                }}>
                    <Box component="form" onSubmit={handleSubmit} noValidate sx={{
                        width: "100%"
                    }}>
                        <Typography
                            component='h1'
                            variant='subtitle1'
                            align='center'
                        >
                            输入cno和bno进行书籍借阅~
                        </Typography>
                        <TextField
                            inputRef={cnoRef}
                            required
                            id="outlined-required"
                            label="cno"
                            autoFocus
                            fullWidth
                            name="cno"
                            autoComplete='cno'
                            sx={{
                                mt: "10px"
                            }}
                        />
                        <TextField
                            inputRef={bnoRef}
                            required
                            id="outlined-required"
                            label="bno"
                            autoFocus
                            fullWidth
                            name="bno"
                            autoComplete='bno'
                            sx={{
                                mt: "10px"
                            }}
                        />
                        <Button
                            type="submit"
                            fullWidth
                            variant="contained"
                            sx={{ mt: 3, mb: 2 }}
                            color={
                                isFirst == 0 ? "primary" : (isQueryFail || !hasBook ? "error" : "success")
                            }
                        >
                            {
                                isFirst == 0 ?
                                    <Box>借书</Box>
                                    : (!isQueryFail && hasBook ? <Box>借书成功!</Box> : <>借书失败</>)
                            }
                        </Button>
                    </Box>
                </Box>
                <Box sx={{
                    display: hasBook ? "none" : "block"
                }}>
                    <Typography
                        component='h1'
                        variant='subtitle1'
                        align='center'
                    >
                        书籍已经被借阅完毕，最近归还信息是
                    </Typography>
                    <BorrowList book_list={bookList} />
                </Box>
            </Container>
        </ThemeProvider>
    )
}

export default BorrowBook;