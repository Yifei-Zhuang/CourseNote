import { ThemeProvider } from '@emotion/react';
import { Button, Container, TextField, Typography } from '@mui/material';
import * as React from 'react'
import theme from "../../theme"
import { Box } from '@mui/material';
import BorrowList from './BorrowList';
import axios from 'axios';
import type { borrow } from '../Book/DisplayAllBook';
const QueryByCard = () => {
    const baseUrl = 'http://localhost:9000'
    const cnoRef = React.useRef<any>('');
    const [bookList, setBooklist] = React.useState([] as borrow[])
    React.useEffect(
        () => {
            setBooklist([])
        }, []
    )
    const handleQuery = () => {
        axios({
            url: `${baseUrl}/api/card/bookBorrowed`,
            method: "get",
            withCredentials: true,
            params: { "cno": cnoRef.current.value }
        }).then(res => setBooklist(res.data.result)).catch(err => console.error(err))
    }
    return (
        <ThemeProvider theme={theme}>
            <Container >
                <Box sx={
                    {
                        width: "100%",
                        mt: "10px"
                    }
                }>
                    <Typography variant="subtitle1" sx={{ textAlign: "center" }}>
                        输入cno进行查询
                    </Typography>
                    <TextField
                        inputRef={cnoRef}
                        required
                        label="input cno here"
                        error={false}
                        fullWidth
                        autoFocus
                        sx={{
                            lineHeight: "1.5em"
                        }}
                    />
                    <Button
                        type="submit"
                        fullWidth
                        variant="contained"
                        sx={{ mt: 3, mb: 2 }}
                        onClick={handleQuery}
                    >
                        查询借阅记录
                    </Button>


                </Box>
                <Box>
                    <BorrowList book_list={bookList} />
                </Box>
            </Container>
        </ThemeProvider >
    )
}


export default QueryByCard;