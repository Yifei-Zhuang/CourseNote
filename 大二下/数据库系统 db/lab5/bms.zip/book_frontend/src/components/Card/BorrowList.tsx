import * as React from 'react'
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import { borrow } from '../Book/DisplayAllBook';
/* 
props:
    {
        booklist: [
            {
                id : 1,
                cno: 1,
                bno: 1,
                borrow_date: 2001-10-03
                return_date: 2001-10-04
            }
        ]
    }

*/
const BorrowList: React.FC<{
    book_list: borrow[]
}> = (props) => {
    let booklist = props.book_list;
    return (
        <TableContainer component={Paper} >
            <Table sx={{ width: "100%", mt: "20px" }} size="medium" aria-label="bookListDisplay">
                <TableHead>
                    <TableRow>
                        <TableCell>BorrowID</TableCell>
                        <TableCell align="right">CardID(cno)</TableCell>
                        <TableCell align="right">BookID(bno)</TableCell>
                        <TableCell align="right">borrow_date</TableCell>
                        <TableCell align="right">return_date</TableCell>
                    </TableRow>
                </TableHead>
                <TableBody sx={{ minHeight: "500px", overflow: "hidden" }}>
                    {
                        booklist.map(
                            (row) => {
                                return (
                                    <TableRow
                                        key={row.id as React.Key}
                                        sx={{ '&:last-child td, &:last-child th': { border: 0 }, height: "1.2em" }}
                                    >
                                        <TableCell component="th" scope="row">
                                            {row.id}
                                        </TableCell>
                                        <TableCell align="right">{row.cno}</TableCell>
                                        <TableCell align="right">{row.bno}</TableCell>
                                        <TableCell align="right">{row.borrow_date}</TableCell>
                                        <TableCell align="right">{row.return_date == "" ? "not returned yet" : row.return_date}</TableCell>
                                    </TableRow>
                                )
                            }
                        )
                    }
                </TableBody>
            </Table>
        </TableContainer >
    )
}



export default BorrowList;