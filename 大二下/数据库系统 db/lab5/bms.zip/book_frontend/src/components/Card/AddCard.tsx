import * as React from 'react';
import { styled } from '@mui/material/styles';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';

import { ThemeProvider } from '@emotion/react';
import theme from "../../theme"
import { Container, createTheme, CssBaseline, TextField, Typography } from '@mui/material';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button'
import axios from 'axios';
const baseUrl = "http://localhost:9000"
const AddCard = () => {
    const cnoRef = React.useRef<any>('')
    const usernameRef = React.useRef<any>('')
    const departmentRef = React.useRef<any>('')
    const [type, setType] = React.useState('T')
    const [isFirst, setIsFirst] = React.useState(0);
    const [isAddingFail, setIsAddingFail] = React.useState(false);
    const [helperText, setHelperText] = React.useState('' as String);

    const handleSubmit = (e: { preventDefault: () => void; }) => {
        e.preventDefault();
        axios(
            {
                url: `${baseUrl}/api/card/addCard`,
                method: "POST",
                withCredentials: true,
                data: {
                    "cno": cnoRef.current.value,
                    "name": usernameRef.current.value,
                    "department": departmentRef.current.value,
                    "type": type
                },
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            }
        ).then(() => {
            setIsAddingFail(false)
            setHelperText("")
        }
        ).catch((err) => {
            setIsAddingFail(true)
            if (typeof (err.response) != "undefined")
                setHelperText(err.response.data.error)
            if (helperText !== "") alert(helperText)
        }).finally(() => {
            setIsFirst(1)
        })
    }
    const types = [{
        value: 'T',
        label: 'T'
    },
    {
        value: 'S',
        label: 'S'
    }
    ]
    return (
        <ThemeProvider theme={theme}>
            <Container>
                <CssBaseline />
                <Box sx={{
                    marginTop: 8,
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                }}>
                    <Box component="form" onSubmit={handleSubmit} noValidate sx={{
                        width: "100%"
                    }}>
                        <Typography
                            component='h1'
                            variant='subtitle1'
                            align='center'
                        >
                            添加借书证
                        </Typography>
                        <TextField
                            inputRef={cnoRef}
                            required
                            id="outlined-required"
                            label="cno"
                            autoFocus

                            name="cno"
                            autoComplete='cno'
                            sx={{
                                mt: "10px"
                            }}
                        />

                        <TextField
                            inputRef={usernameRef}
                            required
                            id="outlined-required"
                            label="username"
                            autoFocus

                            name="username"
                            autoComplete='username'
                            sx={{
                                mt: "10px"
                            }}
                        />
                        <TextField
                            inputRef={departmentRef}
                            required
                            id="outlined-required"
                            label="department"
                            autoFocus

                            name="department"
                            autoComplete='department'
                            sx={{
                                mt: "10px"
                            }}
                        />

                        <TextField
                            id="outlined-required"
                            select
                            label="类型"
                            value={type}
                            onChange={(event) => { setType(event.target.value) }}
                            helperText="选择借书证类型"
                            sx={{
                                mt: "10px"
                            }}
                        >
                            {

                                types.map((choice) => {
                                    return (
                                        <MenuItem key={choice.value} value={choice.value}>
                                            {choice.label}
                                        </MenuItem>
                                    )
                                })
                            }
                        </TextField>
                        <Button
                            type="submit"
                            fullWidth
                            variant="contained"
                            sx={{ mt: 3, mb: 2 }}
                            color={
                                isFirst == 0 ? "primary" : (isAddingFail ? "error" : "success")
                            }
                        >
                            {
                                isFirst == 0 ?
                                    <Box>添加</Box>
                                    : (!isAddingFail ? <Box>添加成功！</Box> : <>添加失败!</>)
                            }
                        </Button>
                    </Box>
                </Box>
            </Container>
        </ThemeProvider >
    )

}

export default AddCard