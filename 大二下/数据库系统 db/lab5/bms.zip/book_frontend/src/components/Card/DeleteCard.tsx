import { ThemeProvider } from '@emotion/react'
import * as React from 'react'
import theme from '../../theme'
import { Container } from '@mui/material'
import { Box } from '@mui/material'
import { CssBaseline } from '@mui/material'
import { Typography } from '@mui/material'
import { TextField } from '@mui/material'
import { Button } from '@mui/material'
import axios from 'axios'
const baseUrl = "http://localhost:9000"
const DeleteCard = () => {
    const cnoRef = React.useRef<any>('')
    const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        const deleteCardUrl = `${baseUrl}/api/card/deleteCard`
        axios({
            url: deleteCardUrl,
            method: "POST",
            withCredentials: true,
            headers: {
                "Content-Type": "application/json"
            },
            data: {
                "cno": cnoRef.current.value
            }
        }).then(res => console.log(res)).catch(err => { console.error(err) })
    }
    return (
        <ThemeProvider theme={theme}>
            <Container>
                <CssBaseline />
                <Box sx={{
                    marginTop: 8,
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                }}>
                    <Box component="form" onSubmit={handleSubmit} noValidate sx={{
                        width: "100%"
                    }}>
                        <Typography
                            component='h1'
                            variant='subtitle1'
                            align='center'
                        >
                            输入cno删除借书证
                        </Typography>
                        <TextField
                            inputRef={cnoRef}
                            required
                            id="outlined-required"
                            label="cno"
                            autoFocus
                            fullWidth
                            name="cno"
                            autoComplete='cno'
                            sx={{
                                mt: "10px"
                            }}
                        />

                        <Button
                            type="submit"
                            fullWidth
                            variant="contained"
                            sx={{ mt: 3, mb: 2 }}
                        >
                            删除
                        </Button>
                    </Box>
                </Box>
            </Container>
        </ThemeProvider>
    )
}

export default DeleteCard