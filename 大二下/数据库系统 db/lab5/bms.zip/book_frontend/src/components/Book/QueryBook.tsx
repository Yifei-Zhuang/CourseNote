import { ThemeProvider } from '@emotion/react';
import { Button, Container, MenuItem, Paper, Typography } from '@mui/material';
import { TextField } from '@mui/material';
import { Box } from '@mui/system';
import { userInfo } from 'os';
import * as React from 'react'

import theme from '../../theme'
import axios from 'axios';
import BookList from './Booklist';
import { Book } from '@mui/icons-material';
import Alert from '@mui/material/Alert';
export function isValidKey(
    key: string | number | symbol, object: object
): key is keyof typeof object {

    return key in object;
}
const QueryBook = () => {
    const searchOptions = ['bno', 'author', 'category', 'title', 'press', 'total', 'stock', 'year', 'price'];
    const [searchOption, setSearchOption] = React.useState('bno');
    const searchRef = React.useRef<any>('');
    const priceMinRef = React.useRef<any>(''), priceMaxRef = React.useRef<any>('');
    const yearMinRef = React.useRef<any>(''), yearMaxRef = React.useRef<any>('');
    const [searchResult, setSearchResult] = React.useState([]);
    const baseUrl = `http://localhost:9000`
    const handleQuery = (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        let lowPrice, highPrice;
        let lowYear, highYear;
        if (searchOption != "price") {
            lowPrice = 1;
            highPrice = 0;
        } else {
            lowPrice = priceMinRef.current!.value;
            highPrice = priceMaxRef.current!.value;
        }
        if (searchOption != "year") {
            lowYear = 1;
            highYear = 0;
        } else {
            lowYear = yearMinRef.current.value
            highYear = yearMaxRef.current.value
        }
        const queryUrl = `${baseUrl}/api/book/queryBook`;
        const myParams = {
            "low_year": lowYear,
            "high_year": highYear,
            "low_price": lowPrice,
            "high_price": highPrice,
        }
        if (searchOption != "year" && searchOption != "price") {
            myParams[`${searchOption}`] = searchRef.current.value;
        }
        // console.log(myParams);
        axios({
            url: queryUrl,
            method: "get",
            withCredentials: true,
            params: myParams
        }).then(res => {
            // console.log("returned", res.data.result)
            setSearchResult(res.data.result)
            // console.log("result", searchResult)
        }).catch(err => console.error(err.response.data.result))
    }
    return (
        <Paper>
            <Container>
                <Box sx={{
                    marginTop: 8,
                    display: 'flex',
                    flexDirection: 'column',
                }}>

                    <Typography component="h1" variant="h2" sx={
                        {
                            margin: 'auto',
                            textAlign: 'center'
                        }
                    }>书籍查询！</Typography>
                    <Typography component="h2" variant="h5" sx={
                        {
                            marginLeft: "2%",
                            marginTop: "20px",
                            fontSize: "1em"
                        }
                    }>限定条件</Typography>
                    <Box component="form" sx={{
                        mt: "20px"
                    }} onSubmit={handleQuery}>
                        <TextField
                            id="outlined-required"
                            select
                            label="类型"
                            value={searchOption}
                            onChange={(event) => { setSearchOption(event.target.value) }}
                            helperText="select type for querying book"
                        >
                            {
                                searchOptions.map(row => {
                                    return (
                                        <MenuItem key={row} value={row}>{row}</MenuItem>
                                    )
                                })
                            }
                        </TextField>
                        {
                            searchOption.toLocaleLowerCase() == "price"
                                ?
                                <>
                                    <TextField
                                        required
                                        inputRef={priceMinRef}
                                        label="最低价"
                                        error={false}
                                    />
                                    <TextField
                                        required
                                        inputRef={priceMaxRef}
                                        label="最高价"
                                        id="maxPrice"
                                        error={false}
                                    />
                                </>
                                :
                                searchOption.toLocaleLowerCase() == "year"
                                    ?
                                    <>
                                        <TextField
                                            required
                                            inputRef={yearMinRef}
                                            label="最小年份"
                                            error={false}
                                        />
                                        <TextField
                                            required
                                            inputRef={yearMaxRef}
                                            label="最大年份"
                                            id="maxYear"
                                            error={false} />

                                    </>
                                    :
                                    <>
                                        <TextField
                                            inputRef={searchRef}
                                            required
                                            id="searchConstrain-required"
                                            label="相等查询"
                                            autoFocus
                                            name="searchConstrain"
                                            autoComplete=''
                                        />
                                    </>
                        }
                        <Button
                            type="submit"
                            fullWidth
                            variant="outlined"
                            sx={{ mt: 3, mb: 2 }}
                        >
                            查询！
                        </Button>
                    </Box>
                </Box>
                <BookList book_list={searchResult} />
            </Container >
        </Paper >
    )

}

export default QueryBook;