import * as React from 'react';
import { styled } from '@mui/material/styles';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';

import { ThemeProvider } from '@emotion/react';
import theme from "../../theme"
import { Container, createTheme, CssBaseline, TextField, Typography } from '@mui/material';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button'
import axios from 'axios';
const baseUrl = "http://localhost:9000"
const AddBook = () => {
    const bnoRef = React.useRef<any>('')
    const authorRef = React.useRef<any>('')
    const categoryRef = React.useRef<any>('')
    const titleRef = React.useRef<any>('')
    const pressRef = React.useRef<any>('')
    const totalRef = React.useRef<any>('')
    const stockRef = React.useRef<any>('')
    const yearRef = React.useRef<any>('')
    const priceRef = React.useRef<any>('')
    const [isFirst, setIsFirst] = React.useState(0);
    const [isAddingFail, setIsAddingFail] = React.useState(false);
    const [helperText, setHelperText] = React.useState('' as String);
    const handleSubmit = (e: { preventDefault: () => void; }) => {
        e.preventDefault();
        axios(
            {
                url: `${baseUrl}/api/book/addBook`,
                method: "POST",
                withCredentials: true,
                data: {
                    "bno": bnoRef.current.value == "" ? "__non__" : bnoRef.current.value,
                    "category": categoryRef.current.value == "" ? "__non__" : categoryRef.current.value,
                    "title": titleRef.current.value == "" ? "__non__" : titleRef.current.value,
                    "press": pressRef.current.value == "" ? "__non__" : pressRef.current.value,
                    "year": Number(yearRef.current.value) == 0 ? -1 : Number(yearRef.current.value),
                    "author": authorRef.current.value == "" ? "__non__" : authorRef.current.value,
                    "price": Number(priceRef.current.value) == 0 ? -1 : Number(priceRef.current.value),
                    "total": Number(totalRef.current.value) == 0 ? -1 : Number(totalRef.current.value),
                    "stock": Number(stockRef.current.value) == 0 ? -1 : Number(stockRef.current.value)
                },
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            }
        ).then(() => {
            setIsAddingFail(false)
            setHelperText("")
        }
        ).catch(err => {
            setIsAddingFail(true)
            setHelperText(err.response.data.error)
        }).finally(() => {
            setIsFirst(1)
        })
    }
    return (
        <ThemeProvider theme={theme}>
            <Container>
                <CssBaseline />
                <Box sx={{
                    marginTop: 8,
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                }}>
                    <Box component="form" onSubmit={handleSubmit} noValidate sx={{
                        width: "100%"
                    }}>
                        <Typography
                            component='h1'
                            variant='subtitle1'
                            align='center'
                        >
                            添加/更新书籍信息
                        </Typography>
                        <TextField
                            inputRef={bnoRef}
                            required
                            id="outlined-required"
                            label="bno"
                            autoFocus
                            fullWidth
                            name="bno"
                            autoComplete='bno'
                            sx={{
                                mt: "10px"
                            }}
                        />

                        <TextField
                            inputRef={authorRef}
                            required
                            id="outlined-required"
                            label="author"
                            autoFocus
                            fullWidth
                            name="author"
                            autoComplete='author'
                            sx={{
                                mt: "10px"
                            }}
                        />
                        <TextField
                            inputRef={categoryRef}
                            required
                            id="outlined-required"
                            label="category"
                            autoFocus
                            fullWidth
                            name="category"
                            autoComplete='category'
                            sx={{
                                mt: "10px"
                            }}
                        />
                        <TextField
                            inputRef={titleRef}
                            required
                            id="outlined-required"
                            label="title"
                            autoFocus
                            fullWidth
                            name="title"
                            autoComplete='title'
                            sx={{
                                mt: "10px"
                            }}
                        />
                        <TextField
                            inputRef={pressRef}
                            required
                            id="outlined-required"
                            label="press"
                            autoFocus
                            fullWidth
                            name="press"
                            autoComplete='category'
                            sx={{
                                mt: "10px"
                            }}
                        />
                        <TextField
                            inputRef={totalRef}
                            required
                            id="outlined-required"
                            label="total"
                            autoFocus
                            fullWidth
                            name="total"
                            autoComplete='total'
                            sx={{
                                mt: "10px"
                            }}
                        />
                        <TextField
                            inputRef={stockRef}
                            required
                            id="outlined-required"
                            label="stock"
                            autoFocus
                            fullWidth
                            name="stock"
                            autoComplete='stock'
                            sx={{
                                mt: "10px"
                            }}
                        />
                        <TextField
                            inputRef={yearRef}
                            required
                            id="outlined-required"
                            label="year"
                            autoFocus
                            fullWidth
                            name="year"
                            autoComplete='year'
                            sx={{
                                mt: "10px"
                            }}
                        />
                        <TextField
                            inputRef={priceRef}
                            required
                            id="outlined-required"
                            label="price"
                            autoFocus
                            fullWidth
                            name="price"
                            autoComplete='price'
                            sx={{
                                mt: "10px"
                            }}
                        />
                        <Button
                            type="submit"
                            fullWidth
                            variant="contained"
                            sx={{ mt: 3, mb: 2 }}
                            color={
                                isFirst == 0 ? "primary" : (isAddingFail ? "error" : "success")
                            }
                        >
                            {
                                isFirst == 0 ?
                                    <Box>添加/更新书籍</Box>
                                    : (!isAddingFail ? <Box>添加/更新成功</Box> : <>失败啦</>)
                            }
                        </Button>
                    </Box>
                </Box>
            </Container>
        </ThemeProvider >
    )

}

export default AddBook