import { ThemeProvider } from '@emotion/react'
import * as React from 'react'
import Booklist from './Booklist'
import theme from "../../theme"
import { Container } from '@mui/material'
import { Typography } from '@mui/material'
import { Box } from '@mui/system'
import axios from 'axios'
export interface borrow {
    id: Number;
    cno: String;
    bno: String;
    borrow_date: String;
    return_date: String;
}
const DisplayAllBook = () => {
    /*{
        booklist: [
            {
                id : 1,
                cno: 1,
                bno: 1,
                borrow_date: 2001-10-03
                return_date: 2001-10-04
            }
        ]
    }*/
    const baseUrl = "http://localhost:9000"
    const [booklist, setBooklist] = React.useState([])
    const getAllBook = () => {
        const allBookUrl = `${baseUrl}/api/book/allBook`;
        axios({
            url: allBookUrl,
            method: "get",
            withCredentials: true,
            headers: {
                'Accept': "application/json"
            }
        }).then(
            res => {
                let temp = res.data.booklist
                temp.sort((a: borrow, b: borrow) => {
                    if (a.bno.length < b.bno.length) return -1;
                    else if (a.bno.length == b.bno.length) return 0;
                    else return 1;
                })
                setBooklist(temp);
            }
        ).catch(
            err => {

                if (err.response === undefined)
                    alert("后端似乎没有启动～")
                else alert(err.response)
            }
        )
    }

    React.useEffect(getAllBook, [])
    return (
        <ThemeProvider theme={theme}>
            <Container>
                <Box>
                    <Typography
                        component='h1'
                        variant='subtitle1'
                        align='center'
                    >
                        所有书籍的信息
                    </Typography>
                    <Booklist book_list={booklist} />
                </Box>
            </Container>
        </ThemeProvider>
    )
}


export default DisplayAllBook;