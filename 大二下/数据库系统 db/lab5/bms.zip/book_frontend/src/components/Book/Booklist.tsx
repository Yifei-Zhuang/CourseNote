import * as React from 'react'
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
export interface book {
    bno: String;
    author: String;
    category: String;
    title: String;
    press: String;
    total: Number;
    stock: Number;
    price: Number;
    year: Number;

}
const BorrowList = (props: {
    book_list: book[]
}) => {
    let bookList = props.book_list;
    return (
        <Table sx={{ width: "100%", mt: "20px" }} size="medium" aria-label="bookListDisplay">
            <TableHead>
                <TableRow>
                    <TableCell>bno</TableCell>
                    <TableCell align="right">Author</TableCell>
                    <TableCell align="right">Category</TableCell>
                    <TableCell align="right">Title</TableCell>
                    <TableCell align="right">Press</TableCell>
                    <TableCell align="right">Total</TableCell>
                    <TableCell align="right">Stock</TableCell>
                    <TableCell align="right">Price</TableCell>
                    <TableCell align="right">Year</TableCell>
                </TableRow>
            </TableHead>
            <TableBody sx={{ minHeight: "500px", overflow: "hidden" }}>
                {
                    bookList.map(
                        (row) => {
                            return (
                                <TableRow
                                    key={row.bno as React.Key}
                                    sx={{ '&:last-child td, &:last-child th': { border: 0 }, height: "1.2em" }}
                                >
                                    <TableCell component="th" scope="row">
                                        {row.bno}
                                    </TableCell>
                                    <TableCell align="right">{row.author}</TableCell>
                                    <TableCell align="right">{row.category}</TableCell>
                                    <TableCell align="right">{row.title}</TableCell>
                                    <TableCell align="right">{row.press}</TableCell>
                                    <TableCell align="right">{row.total}</TableCell>
                                    <TableCell align="right">{row.stock}</TableCell>
                                    <TableCell align="right">{row.price}</TableCell>
                                    <TableCell align="right">{row.year}</TableCell>
                                </TableRow>
                            )
                        }
                    )
                }
            </TableBody>
        </Table>
        // </TableContainer >
    )
}



export default BorrowList;