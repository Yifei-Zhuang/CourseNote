import * as React from 'react'
import { AppBar as MuiAppBar, AppBarProps as MuiAppBarProps, CssBaseline, Toolbar, Typography } from '@mui/material';
import styled from '@emotion/styled';
import { drawerWidth } from './SideBar';
export interface AppBarProp extends MuiAppBarProps {
    open: boolean
}
const AppBar = styled(MuiAppBar, {
    shouldForwardProp: props => props !== "open"
})<AppBarProp>(({ theme, open }) => ({
    "& .MuiToolbar-regular": {
        display: "flex",
        p: "8px",
        height: "2em",
        paddingLeft: 100,
        transition: (theme as any).transitions.create(["width", "margin", "padding"], {
            duration: (theme as any).transitions.duration.shortest
        }),
        ...(
            open && {
                paddingLeft: drawerWidth + 20,
                transition: (theme as any).transitions.create(["width", "margin", "padding"], {
                    duration: (theme as any).transitions.duration.shortest
                }),
                width: `calc(100% - ${drawerWidth}px)`,
            }
        )
    }
}))
interface TopBarProps {
    open: boolean;
}
function TopBar(props: TopBarProps) {
    let { open } = props;
    return (
        <AppBar open={open} position="absolute" >
            <Toolbar >
                <Typography
                    component="h1"
                    variant="h6"
                    color="inherit"
                    noWrap
                    sx={{ flexGrow: 1 }}
                >
                    图书馆管理系统
                </Typography>
            </Toolbar>
        </AppBar >
    )
}

export default TopBar;