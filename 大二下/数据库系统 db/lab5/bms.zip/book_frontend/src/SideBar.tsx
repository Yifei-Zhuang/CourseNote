import { CssBaseline, Divider, Drawer as MuiDrawer, IconButton, ListItem, ListItemButton, ListItemText, Typography } from '@mui/material';
import * as React from 'react'
import List from '@mui/material/List'
import { Toolbar } from '@mui/material';
import Link from 'next/link';
import LoginIcon from '@mui/icons-material/Login'
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import CreditCardIcon from '@mui/icons-material/CreditCard';
import QueryStatsIcon from '@mui/icons-material/QueryStats';
import LibraryBooksIcon from '@mui/icons-material/LibraryBooks';
import CallToActionIcon from '@mui/icons-material/CallToAction';
import styled from '@emotion/styled';
import { Button } from '@mui/material';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
export const drawerWidth: number = 230;
const Drawer = styled(MuiDrawer, { shouldForwardProp: props => props !== "open" })(({ theme, open }) => ({
    "& .MuiDrawer-paper": {
        position: "relative",
        width: drawerWidth,
        transition: (theme as any).transitions.create(["width"], {
            duration: (theme as any).transitions.duration.shortest,
        }),
        ...(!open && {
            transition: (theme as any).transitions.create(["width"], {
                duration: (theme as any).transitions.duration.shortest,
            }),
            overflowX: "hidden",
            width: (theme as any).spacing(10)
        })
    }
}))

export interface choice {
    id: number;
    url: string;
    value: string;
}
export interface sideBarProps {
    linksList: choice[];
    open: boolean;
    setOpen: React.Dispatch<React.SetStateAction<boolean>>
}
function SideBar(props: sideBarProps) {
    let { linksList, open, setOpen } = props;
    const ButtonPos = open ? { right: "6px" } : { left: "6px" };
    return (
        <Drawer variant="permanent" sx={{
            width: { drawerWidth },
            // position: "fixed"
        }} open={open}>
            <Toolbar
                sx={{
                    display: "flex",
                    justifyContent: "flex-end",
                    alignItems: "center",
                }}

            >
                {/* <IconButton onClick={() => { setOpen(!open) }} sx={{
                    position: "absolute",
                    ...{ ButtonPos }
                }} >
                    {
                        open ? <ChevronLeftIcon /> : <ChevronRightIcon />
                    }
                </IconButton> */}
            </Toolbar>
            <Divider />
            <List component="nav" aria-label="sideNavigator" sx={{
                display: "flex",
                flexDirection: "column",
                flexWrap: "wrap"
            }}>
                {linksList.map(
                    (item) => {
                        return (
                            <Link href={`${item.url}`} key={`${item.url}`}>
                                <ListItemButton >
                                    {
                                        item.id === 1 ? <LoginIcon />
                                            : (item.id === 2 ? <AccountCircleIcon /> :
                                                (item.id === 3 ? <CreditCardIcon /> :
                                                    (item.id === 4 ? <QueryStatsIcon /> :
                                                        (item.id === 5 ? <CallToActionIcon /> :
                                                            (item.id === 6 ? <LibraryBooksIcon /> : <></>)))))
                                    }
                                    <ListItemText primary={item.value} sx={{
                                        zIndex: -1,
                                        marginLeft: "1em",
                                    }} />
                                </ListItemButton>
                            </Link>
                        )
                    }
                )}
            </List>
        </Drawer>
    )
}

export default SideBar;