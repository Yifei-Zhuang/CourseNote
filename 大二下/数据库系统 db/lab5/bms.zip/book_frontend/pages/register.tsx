import * as React from 'react';
import type { NextPage } from 'next';
import RegisterBox from '../src/components/Register'
const Register: NextPage = () => {
    return (
        <RegisterBox />
    )
}
export default Register