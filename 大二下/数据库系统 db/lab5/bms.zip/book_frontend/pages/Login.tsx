import * as React from 'react';
import type { NextPage } from 'next';
import SignIn from '../src/components/Login';
const Login: NextPage = () => {
    return (
        <SignIn />
    )
}
export default Login