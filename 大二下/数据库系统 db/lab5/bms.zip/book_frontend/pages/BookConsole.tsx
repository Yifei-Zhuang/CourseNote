import * as React from 'react'
import { NextPage } from 'next'
import AddBook from '../src/components/Book/AddBook'
import DisplayAllBook from '../src/components/Book/DisplayAllBook'
import QueryBook from '../src/components/Book/QueryBook'
import { CssBaseline, TextField } from '@mui/material'
import { Box } from '@mui/system'
import { MenuItem } from '@mui/material'
const BookConsole: NextPage = () => {
    const [type, setType] = React.useState("1");
    const types = [
        {
            value: 1,
            desc: "获取所有书籍信息"
        },
        {
            value: 2,
            desc: "添加/更新书籍"
        },
        {
            value: 3,
            desc: "书籍查询"
        }
    ]
    return (
        <Box sx={{
            "display": "flex"
        }}>
            <TextField
                id="outlined-required"
                select
                label="选择管理项"
                value={type}

                onChange={(event) => { setType(event.target.value) }}
                helperText="管理类别"
                sx={{
                    mt: "10px",
                    minWidth: "10em"
                }}
            >
                {

                    types.map((choice) => {
                        return (
                            <MenuItem key={choice.value} value={choice.value}>
                                {choice.desc}
                            </MenuItem>
                        )
                    })
                }
            </TextField>
            <CssBaseline />
            {
                type == "1" ? (
                    <Box sx={{
                        minWidth: "80%",
                        paddingLeft: "10%",
                        paddingRight: "10%"
                    }} >
                        <DisplayAllBook />
                    </Box>) : (type == "2" ?
                        <Box sx={{
                            minWidth: "80%",
                            paddingLeft: "10%",
                            paddingRight: "10%"
                        }}>
                            <AddBook />
                        </Box> :
                        <Box sx={{
                            minWidth: "80%",
                            paddingLeft: "10%",
                            paddingRight: "10%"
                        }}>
                            <QueryBook />
                        </Box>)
            }
        </Box >
    )
}

export default BookConsole;