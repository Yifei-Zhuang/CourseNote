import * as React from 'react';
import type { NextPage } from 'next';
import SignIn from '../src/components/Login';
import { Typography } from '@mui/material';
import { Box } from '@mui/material';
const Login: NextPage = () => {
  return (
    <Box sx={{
      display: "flex",
      justifyContent: "center",
      alignItems: "center"
    }}>
      <Typography component="h1" variant="h1">
        Welcome to BMS!
      </Typography>
    </Box>
  )
}
export default Login