import * as React from 'react'
import { NextPage } from 'next'
import AddCard from "../src/components/Card/AddCard"
import DeleteCard from '../src/components/Card/DeleteCard'
import QueryByCard from '../src/components/Card/QueryByCard'
import { CssBaseline } from '@mui/material'
import { Box } from '@mui/system'
const CardConsole: NextPage = () => {
    return (

        <Box>
            <CssBaseline />
            <AddCard />
            <CssBaseline />
            <DeleteCard />
        </Box>

    )
}

export default CardConsole;