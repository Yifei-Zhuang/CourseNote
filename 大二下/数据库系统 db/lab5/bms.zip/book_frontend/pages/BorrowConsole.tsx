import * as React from 'react'
import { NextPage } from 'next'
import BorrowBook from '../src/components/Borrow/BorrowBook'
import ReturnBorrow from '../src/components/Borrow/ReturnBorrow'
import { CssBaseline } from '@mui/material'
import { Box } from '@mui/system'
const BorrowConsole: NextPage = () => {
    return (
        <Box >
            <CssBaseline />
            <BorrowBook />
            <CssBaseline />
            <ReturnBorrow />
        </Box>
    )
}

export default BorrowConsole;