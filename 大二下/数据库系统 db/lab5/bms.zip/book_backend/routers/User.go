package routers

import (
	"book_backend/auth"
	"book_backend/database"
	"book_backend/model"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
	"net/http"
)

func VerifyUser(c *gin.Context) {
	var user model.User
	if err := c.ShouldBindJSON(&user); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": "invalid request",
		})
		return
	}
	// TODO 添加jwt逻辑
	if user.UserName == "" || user.Password == "" {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": "missing json data username or password",
		})
		return
	}
	var userInDB model.User
	if err := database.DB.Where("username = ?", user.UserName).First(&userInDB).Error; err == gorm.ErrRecordNotFound {
		c.JSON(http.StatusUnauthorized, gin.H{
			"error": "this user doesn't exists",
		})
		return
	}
	if userInDB.Password != user.Password {
		c.JSON(http.StatusUnauthorized, gin.H{
			"error": "wrong password",
		})
		return
	}
	token, _ := auth.GenerateToken(&user)
	c.SetCookie("__BMSUSERCOOKIE", token, 600, "/", "localhost", false, false)
	c.JSON(http.StatusOK, gin.H{})
}
func Register(c *gin.Context) {
	//TODO complete
	var user model.User
	if err := c.ShouldBindJSON(&user); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": "invalid request",
		})
		return
	}
	if user.UserName == "" || user.Password == "" {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": "missing json data username or password",
		})
		return
	}
	var userInDB model.User
	if err := database.DB.Where("username = ?", user.UserName).First(&userInDB).Error; err != gorm.ErrRecordNotFound {
		c.JSON(http.StatusUnauthorized, gin.H{
			"error": "this user already exists",
		})
		return
	}
	database.DB.Create(&user)
	c.JSON(http.StatusOK, gin.H{})
}
