package routers

import (
	"book_backend/database"
	"book_backend/model"
	"github.com/gin-gonic/gin"
	"net/http"
	"sort"
	"time"
)

type BorrowBookStruct struct {
	Cno string `json:"cno"`
	Bno string `json:"bno"`
}
type LastBookStruct struct {
	ID          int    `json:"id" gorm:"primaryKey;autoIncrement"`
	CardCno     string `json:"cno" gorm:"references:Cno;column:cno;primaryKey;size:7"`
	BookBno     string `json:"bno" gorm:"references:Bno;column:bno;primaryKey;size:8"`
	Borrow_date string `json:"borrow_date"`
	Return_date string `json:"return_date"`
}

func HandleBorrowBook(c *gin.Context) {
	var json BorrowBookStruct
	err := c.ShouldBindJSON(&json)
	if err != nil || json.Bno == "" || json.Cno == "" {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": "missing json body or cno or bno",
		})
		return
	}
	if err := database.AddBorrow(&model.Borrow{
		CardCno:     json.Cno,
		BookBno:     json.Bno,
		Borrow_date: time.Now().Format("2006-01-02"),
		Return_date: "",
	}); err != nil {
		var books model.ByRetDate
		database.DB.Where("bno = ?", json.Bno).Find(&books)

		if len(books) == 0 {
			c.JSON(http.StatusBadRequest, gin.H{
				"error": err.Error(),
				"books": &LastBookStruct{
					ID: -1,
				},
			})
		} else {
			sort.Sort(books)
			c.JSON(http.StatusBadRequest, gin.H{
				"error": err.Error(),
				"books": &LastBookStruct{
					ID:          books[0].ID,
					CardCno:     books[0].CardCno,
					BookBno:     books[0].BookBno,
					Borrow_date: books[0].Borrow_date,
					Return_date: books[0].Return_date,
				},
			})
		}
		return
	}
	c.JSON(http.StatusOK, gin.H{
		"msg": "success",
	})

}

type returnBookStruct struct {
	Cno string `json:"cno"`
	Bno string `json:"bno"`
}

func HandleReturnBook(c *gin.Context) {
	var json returnBookStruct
	err := c.ShouldBindJSON(&json)
	if err != nil || json.Cno == "" || json.Bno == "" {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": "missing json body or cno or bno",
		})
		return
	}
	if err := database.ReturnBorrow(&model.Borrow{
		CardCno: json.Cno,
		BookBno: json.Bno,
	}); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": err.Error(),
		})
		return
	}
	c.JSON(http.StatusOK, gin.H{
		"msg": "success",
	})
}
