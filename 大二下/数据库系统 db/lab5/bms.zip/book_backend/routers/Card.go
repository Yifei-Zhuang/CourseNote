package routers

import (
	"book_backend/database"
	"book_backend/model"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
	"gorm.io/gorm/utils"
	"net/http"
)

//获取借的所有书
func HandleBookBorrowed(c *gin.Context) {
	var borrows []model.Borrow
	var cno string = c.Query("cno")
	if cno == "" || len(cno) > 7 {
		c.JSON(http.StatusBadRequest, gin.H{"invalid_cno": cno})
		return
	}
	database.DB.Where("cno = ?", cno).Find(&borrows)
	c.JSON(http.StatusOK, gin.H{"result": borrows})
}
func HandleCardAdd(c *gin.Context) {
	var json model.Card
	err := c.BindJSON(&json)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "JSON解析失败" + utils.ToString(json)})
		return
	}
	if json.Department == "" || json.Cno == "" || json.Name == "" || json.Type == "" {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": "missing field",
		})
		return
	}
	if err := database.DB.Where("cno = ? ", json.Cno).First(&model.Card{}).Error; err != gorm.ErrRecordNotFound {
		c.JSON(http.StatusBadRequest, gin.H{"error": "重复主键"})
		return
	}
	if json.Type != "T" && json.Type != "S" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "无效类型"})
		return
	}

	database.DB.Create(&json)
	c.JSON(http.StatusOK, gin.H{})
}

type cnoStruct struct {
	Cno string `json:"cno"`
}

func HandleCardDelete(c *gin.Context) {
	var cno cnoStruct
	err := c.ShouldBindJSON(&cno)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "missing cno"})
		return
	}
	database.DB.Where("cno = ? ", cno.Cno).Delete(&model.Card{})
	c.JSON(http.StatusOK, gin.H{
		"status": "delete " + cno.Cno + " succeeefully",
	})
}
