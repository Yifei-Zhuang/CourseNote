package routers

import (
	"book_backend/Utils"
	"book_backend/database"
	"book_backend/model"
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/gin-gonic/gin/binding"
	"gorm.io/gorm"
	"net/http"
	"strconv"
	"strings"
)

/*
	@return: 返回数据库中所有的书
*/
func HandlebookList(c *gin.Context) {
	var BookList []model.Book
	database.DB.Find(&BookList)
	c.JSON(http.StatusOK, gin.H{"booklist": &BookList})
}

func HandleAddBook(c *gin.Context) {
	var book model.Book
	err := c.ShouldBindBodyWith(&book, binding.JSON)
	fmt.Println(book)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": "invalid json format",
		})
		return
	}
	if book.Bno == "__non__" {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": "missing field",
		})
		return
	}
	if err := database.DB.Where("bno=?", book.Bno).First(&model.Book{}).Error; err != gorm.ErrRecordNotFound {
		HandleUpdateBook(c)
		return
	}

	if book.Bno == "__non__" || book.Author == "__non__" || book.Category == "__non__" || book.Title == "__non__" || book.Press == "__non__" || book.Price == -1 || book.Stock == -1 || book.Total == -1 || book.Year == -1 {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": "missing field",
		})
		return
	}
	if err := database.AddBook(&book); err != nil {
		c.JSON(http.StatusBadGateway, gin.H{"error": err.Error()})
	} else {
		c.JSON(http.StatusOK, gin.H{})
	}
}

func HandleUpdateBook(c *gin.Context) {
	// if a number is -1, regard it as null
	// if a string is __non__,regrad is as null
	var book, original model.Book
	err := c.ShouldBindBodyWith(&book, binding.JSON)
	if err != nil {
		if book.Bno == "" {
			c.JSON(http.StatusBadRequest, gin.H{
				"error": "missing bno",
			})
			return
		}
	}

	err = database.DB.Where("bno = ? ", book.Bno).First(&original).Error
	if err == gorm.ErrRecordNotFound {
		// 记录原先不存在，直接创建
		database.DB.Create(&book)
	} else {
		if book.Bno == "__non__" {
			book.Bno = original.Bno
		}
		if book.Author == "__non__" {
			book.Author = original.Author
		}
		if book.Category == "__non__" {
			book.Category = original.Category
		}
		if book.Title == "__non__" {
			book.Title = original.Title
		}
		if book.Press == "__non__" {
			book.Press = original.Press
		}
		if book.Total == -1 {
			book.Total = original.Total
		}
		if book.Stock == -1 {
			book.Stock = original.Stock
		}
		if book.Year == -1 {
			book.Year = original.Year
		}
		if book.Price == -1 {
			book.Price = original.Price
		}
		//记录原先就存在，开始更新
		if err := database.DB.Save(&book).Error; err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": strings.Split(err.Error(), ":")[1]})
			return
		}
	}
	c.JSON(http.StatusOK, gin.H{})
}

/*
	@param:low_xx, high_xx保证存在，如果传入的low > high，那么认为不存在该查询条件
*/
//curl http://localhost:9000/api/book/queryBook\?low_year\=10\&high_year\=-1\&low_price\=111.10\&high_price\=2002
func HandleQueryBook(c *gin.Context) {

	var book model.Book
	book.Bno = c.Query("bno")
	if book.Bno != "" {
		//直接根据主键查找
		database.DB.Where("bno=?", book.Bno).First(&book)
		var BookList []model.Book
		BookList = append(BookList, book)
		c.JSON(http.StatusOK, gin.H{"result": &BookList})
		return
	}
	var low_year, high_year int
	var low_price, high_price float64
	var temp string
	temp = c.Query("low_year")
	low_year, _ = strconv.Atoi(temp)
	temp = c.Query("high_year")
	high_year, _ = strconv.Atoi(temp)

	temp = c.Query("low_price")
	low_price, _ = strconv.ParseFloat(temp, 64)
	temp = c.Query("high_price")
	high_price, _ = strconv.ParseFloat(temp, 64)

	var BookList []model.Book
	database.DB.Find(&BookList)
	Utils.FilterByPriceRange(&BookList, low_price, high_price)
	Utils.FilterByYearRange(&BookList, low_year, high_year)

	var hasCategory, hasTitle, hasPress, hasAuthor, hasTotal, hasStock bool
	book.Category, hasCategory = c.GetQuery("category")
	book.Title, hasTitle = c.GetQuery("title")
	book.Press, hasPress = c.GetQuery("press")
	fmt.Println("press", book.Press)
	book.Author, hasAuthor = c.GetQuery("author")
	temp, hasTotal = c.GetQuery("total")
	book.Total, _ = strconv.Atoi(temp)
	temp, hasStock = c.GetQuery("stock")
	book.Stock, _ = strconv.Atoi(temp)

	if hasCategory {
		CategoryEqual := func(newbook *model.Book) bool {
			return newbook.Category == book.Category
		}
		Utils.GeneralFilter(&BookList, CategoryEqual)
	}

	if hasTitle {
		TitleEqual := func(newbook *model.Book) bool {
			return newbook.Title == book.Title
		}
		Utils.GeneralFilter(&BookList, TitleEqual)
	}

	if hasPress {
		PressEqual := func(newbook *model.Book) bool {
			return newbook.Press == book.Press
		}
		Utils.GeneralFilter(&BookList, PressEqual)
	}

	if hasAuthor {
		authorEqual := func(newbook *model.Book) bool {
			return newbook.Author == book.Author
		}
		Utils.GeneralFilter(&BookList, authorEqual)
	}
	if hasTotal {
		totalEqual := func(newbook *model.Book) bool {
			return newbook.Total == book.Total
		}
		Utils.GeneralFilter(&BookList, totalEqual)
	}
	if hasStock {
		StockEqual := func(newbook *model.Book) bool {
			return newbook.Stock == book.Stock
		}
		Utils.GeneralFilter(&BookList, StockEqual)
	}
	c.JSON(http.StatusOK, gin.H{"result": &BookList})
}
