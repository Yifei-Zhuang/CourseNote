package model

type Test struct {
	BookBno string `gorm:"references:Bno;column:Bno"`
	Book    Book
}
