package model

import "time"

type Borrow struct {
	ID          int    `json:"id" gorm:"primaryKey;autoIncrement"`
	CardCno     string `json:"cno" gorm:"references:Cno;column:cno;primaryKey;size:7"`
	BookBno     string `json:"bno" gorm:"references:Bno;column:bno;primaryKey;size:8"`
	Borrow_date string `json:"borrow_date"`
	Return_date string `json:"return_date"`
	Book        Book   // 外键约束 实际不存在
	Card        Card   //外键约束 实际不存在
}
type ByRetDate []Borrow

func (b ByRetDate) Len() int {
	return len(ByRetDate{})
}
func (b ByRetDate) Swap(i, j int) {
	b[i], b[j] = b[j], b[i]
}
func (b ByRetDate) Less(i, j int) bool {
	pre, _ := time.Parse("2006-01-02", b[i].Return_date)
	beh, _ := time.Parse("2006-01-02", b[j].Return_date)
	return pre.Before(beh)
}
