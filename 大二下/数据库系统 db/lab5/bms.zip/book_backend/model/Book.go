package model

type Book struct {
	Bno      string  `json:"bno" gorm:"primaryKey;size:10"`
	Category string  `json:"category" gorm:"size:40"`
	Title    string  `json:"title" gorm:"size:40"`
	Press    string  `json:"press" gorm:"size:40"`
	Year     int     `json:"year"`
	Author   string  `json:"author" gorm:"size:10"`
	Price    float64 `json:"price" gorm:"size:10"`
	Total    int     `json:"total"`
	Stock    int     `json:"stock"`
}
