package model

type Card struct {
	Cno        string `json:"cno" gorm:"primaryKey;size:7"`
	Name       string `json:"name" gorm:"size:10"`
	Department string `json:"department" gorm:"size:40"`
	Type       string `json:"type" gorm:"size:1;check type in ('T','S')"`
}
