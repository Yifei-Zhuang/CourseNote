package model

import "github.com/golang-jwt/jwt"

type UserError int

const (
	MISSINGUSER = iota
	ERRORPASSWORD
)

type User struct {
	UserName string `json:"username" gorm:"primaryKey;column:username"`
	Password string `json:"password" gorm:"NOT NULL"`
}

type UserClaims struct {
	User
	jwt.StandardClaims
}
