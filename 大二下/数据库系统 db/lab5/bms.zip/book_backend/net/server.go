package net

import (
	"book_backend/middleware"
	"book_backend/routers"
	"github.com/gin-gonic/gin"
	"log"
)

func StartWebServer() {
	gin.SetMode(gin.ReleaseMode)
	r := gin.Default()
	r.Use(middleware.Cors())
	bookRouter := r.Group("/api/book")
	bookRouter.GET("allBook", routers.HandlebookList)
	bookRouter.POST("addBook", routers.HandleAddBook)
	bookRouter.POST("updateBook", routers.HandleUpdateBook)
	bookRouter.GET("queryBook", routers.HandleQueryBook)
	////TODO 批量入库功能：
	//
	cardRouter := r.Group("/api/card", middleware.AuthTokenMiddleWare())
	cardRouter.GET("bookBorrowed", routers.HandleBookBorrowed)
	cardRouter.POST("addCard", routers.HandleCardAdd)
	cardRouter.POST("deleteCard", routers.HandleCardDelete)

	borrowRouter := r.Group("/api/borrow", middleware.AuthTokenMiddleWare())
	borrowRouter.POST("borrowBook", routers.HandleBorrowBook)
	borrowRouter.POST("returnBorrow", routers.HandleReturnBook)

	authRouter := r.Group("/api/auth")
	authRouter.POST("login", routers.VerifyUser)
	authRouter.POST("register", routers.Register)

	log.Fatal(r.Run(":9000"))
}
