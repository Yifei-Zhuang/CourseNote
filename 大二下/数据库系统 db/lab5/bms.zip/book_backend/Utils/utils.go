package Utils

import (
	"book_backend/database"
	"book_backend/model"
	"bufio"
	"errors"
	"fmt"
	"os"
	"strconv"
	"strings"
)

func FilterByYearRange(books *([]model.Book), low_year, high_year int) {
	if low_year > high_year {
		return
	}
	var index int = 0
	for _, d := range *books {
		if d.Year >= low_year && d.Year <= high_year {
			(*books)[index] = d
			index += 1
		}
	}
	*books = ((*books)[:index])
}

func FilterByPriceRange(books *([]model.Book), low_price, high_price float64) {
	if low_price > high_price {
		return
	}
	var index int = 0
	for _, d := range *books {
		if d.Price >= low_price && d.Price <= high_price {
			(*books)[index] = d
			index += 1
		}
	}
	*(books) = (*books)[:index]
}

type cmp func(books *model.Book) bool

func GeneralFilter(books *([]model.Book), function cmp) {
	var index int = 0
	for _, d := range *books {
		if function(&d) {
			(*books)[index] = d
			index += 1
		}
	}
	*(books) = (*books)[:index]
}

func ReadInBooks() error {
	var filePath string
	fmt.Println("输入书籍文件地址，如果不需要进行录入书籍信息，请输入\"__NONEED__\"")
	fmt.Scanf("%s", &filePath)
	if filePath == "__NONEED__" {
		return nil
	}
	fp, err := os.Open(filePath)
	defer fp.Close()
	if err != nil {
		return errors.New("cannot read in db")
	}
	buffer := bufio.NewScanner(fp)
	for {
		if !buffer.Scan() {
			break
		}
		line := buffer.Text()
		line = line[1:]
		line = line[:len(line)-1]
		args := strings.Split(line, ",")
		for i := 0; i < len(args); i++ {
			args[i] = strings.TrimSpace(args[i])
		}
		var book model.Book
		book.Bno = args[0]
		book.Category = args[1]
		book.Title = args[2]
		book.Press = args[3]
		book.Year, _ = strconv.Atoi(args[4])
		book.Author = args[5]
		book.Price, _ = strconv.ParseFloat(args[6], 64)
		book.Total, _ = strconv.Atoi(args[7])
		book.Stock = book.Total
		database.AddBook(&book)
	}
	fmt.Println("书籍信息录入成功")
	return nil
}
