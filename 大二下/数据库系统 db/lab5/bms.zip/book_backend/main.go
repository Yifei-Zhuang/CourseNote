package main

import (
	"book_backend/Utils"
	"book_backend/database"
	"book_backend/net"
	"fmt"
)

func main() {
	if err := database.DBInit(); err != nil {
		panic(err)
	}
	result, _ := database.DB.DB()
	defer result.Close()
	if err := Utils.ReadInBooks(); err != nil {
		fmt.Println(err.Error())
	}
	net.StartWebServer()
}
