# Book Management System 2022

Author: 软工2002 庄毅非 3200105872

## usage：

请确保您的计算机中安装有golang编译器，之后请您修改/conf/config.yaml文件进行数据库信息的配置，之后，请您在本文件下运行`go mod tidy; go build;`
之后运行生成的book_backend文件即可运行BMS后端系统，如果在执行`go mod tidy;`的时候长时间无法下载相关包，请您在终端中运行`export GOPROXY=https://goproxy.io,direct
;`配置代理源，之后在运行`go mod tidy 和go build;`即可生成可执行文件

## Function

1. 批量导入图书文件，在运行后端系统的时候，您可能会注意到系统会提示您输入存储书籍信息的文件的地址，如果您需要进行录入，请您输入文件地址，否则请您输入`__NONEED__`，程序将不会进行信息录入

2. 图书信息文件的示例为本目录中的bookDB文件

   ```markdown
   ( book_no_1,computer_science , computer architechure, xxx, 2003, xxx ,90.00, 2)
   ( book_no_2,physics_science , physics theroy,   xxx, 2010, xxx ,190.00, 50   )
   ( book_no_3,math , physics theroy,   xxx, 2010, xxx ,190.00, 50 )
   ( book_no_4,math , math theroy,   xxx, 2010, xxx ,190.00, 50 )
   ( book_no_5,science , science theroy,   xxx, 2010, xxx ,190.00, 50 )
   ( book_no_6,zju , zju theroy,   xxx, 2010, xxx ,190.00, 50 )
   ( book_no_7,spider , spider theroy,   xxx, 2010, xxx ,190.00, 50 )
   ( book_no_8,movie , movie theroy,   xxx, 2010, xxx ,190.00, 50 )
   ( book_no_9,java , java theroy,   xxx, 2010, xxx ,190.00, 50 )
   ( book_no_10,cpp , cpp theroy,   xxx, 2010, xxx ,190.00, 50 )
   ( book_no_11,csp , csp theroy,   xxx, 2010, xxx ,190.00, 50 )
   ( book_no_12,pintia , pintia theroy,   xxx, 2010, xxx ,190.00, 50 )
   ( book_no_13,golang , golang theroy,   xxx, 2010, xxx ,190.00, 50 )
   ( book_no_14,mlea , mlea theroy,   xxx, 2010, xxx ,190.00, 50 )
   
   ```

   