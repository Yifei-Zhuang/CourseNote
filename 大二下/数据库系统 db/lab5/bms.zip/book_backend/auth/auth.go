package auth

import (
	"book_backend/model"
	"errors"
	"github.com/golang-jwt/jwt"
	"strings"
	"time"
)

var sign []byte = []byte("jwtKey")

func GenerateToken(user *model.User) (string, error) {
	nowTime := time.Now()
	//令牌有效期10分钟
	expireTime := nowTime.Add(600 * time.Second)
	issuer := "zyf"
	cliams := model.UserClaims{
		User: model.User{
			UserName: user.UserName,
			Password: user.Password,
		},
		StandardClaims: jwt.StandardClaims{
			ExpiresAt: expireTime.Unix(),
			Issuer:    issuer,
		},
	}
	token, err := jwt.NewWithClaims(jwt.SigningMethodHS256, cliams).SignedString(sign)
	return token, err
}

func ParseToken(token string) (*model.User, error) {
	// TODO multile cookie may have bug
	tokens := strings.Split(token, "=")
	var pos int
	for index, v := range tokens {
		if v == "__BMSUSERCOOKIE" {
			pos = index + 1
			break
		}
	}
	token = tokens[pos]
	tokenClaims, err := jwt.ParseWithClaims(token, &model.UserClaims{}, func(token *jwt.Token) (interface{}, error) {
		return sign, nil
	})
	if err != nil {
		return nil, errors.New("unauthorized operation or you need to relogin")
	}
	if tokenClaims != nil {
		if claims, ok := tokenClaims.Claims.(*model.UserClaims); ok && tokenClaims.Valid {
			return &claims.User, nil
		}
	}
	return nil, errors.New("unauthorized operation or you need to relogin")

}
