//
// Created by 庄毅非 on 2021/4/1.
//
#include"info.h"
extern Item* input();
extern Item* add(Item *);
extern Item* subtract(Item *);
extern Item* multiply(Item*);
extern void outPut(Item*);
//进行第一个多项式的输入
void init(){
    printf("请输入多项式的元数\n");
    scanf("%d",&degree);
    printf("在程序运行的开始，我们需要您先输入一个多项式进行处理\n");
    head = input();
    printf("多项式初始化完成，接下来您可以对多项式进行其他操作\n");
}
//进行菜单展示，同时为各个运算子程序的入口
void menu(int choice){
    printf("请注意 执行多项式输入会覆盖已经输入多项式或保存的计算结果\n");
    do{
        fflush(stdin);
        printf("程序菜单; 1-多项式输入; 2-多项式加(+); 3-多项式减(-); 4-多项式乘(*); 5-输出当前存储的多项式; 0-退出");
        fflush(stdin);
        printf("请输入你想要执行的操作对应的数字\n");
        fflush(stdin);
        scanf("%d",&choice);
        switch(choice){
            case 0:exit(0);
            case 1:head = input();break;
            case 2:head = add(head);break;
            case 3:head = subtract(head);break;
            case 4:head = multiply(head);break;
            case 5:outPut(head);break;
            default:printf("请输入1~5之间的数字\n");break;
        }
    }while(1);
}

