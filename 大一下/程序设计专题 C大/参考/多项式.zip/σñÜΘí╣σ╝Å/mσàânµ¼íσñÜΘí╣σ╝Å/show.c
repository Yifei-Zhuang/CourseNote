//
// Created by 庄毅非 on 2021/4/1.
//
#include"info.h"
//根据输入的系数确定输出格式
void print(int x,struct times *varInfo,int len){
    if(x == -1) printf("-");
    else if(x != 1) printf("%d",x);
//    qsort(varInfo,len,sizeof(struct times),comperateTwoVariable);
    for(int i=0;i<len;i++) {
        if (varInfo[i].exp != 0) {
            if (varInfo[i].exp != 1)
                printf("x%d^%d", varInfo[i].tar, varInfo[i].exp);
            else printf("x%d", varInfo[i].tar);
        }
    }
}

//输入输入的头指针对应的多项式
void outPut(Item *list){
    if(list->next == NULL) printf("多项式为空值(0)\n");
    else{
        print(list->next->coef,list->next->exp.timesArray,list->next->exp.length);
        Item *pMove = list->next->next;
        while(pMove!=NULL){
            if(pMove->coef>0)
                printf("+");
            print(pMove->coef,pMove->exp.timesArray,pMove->exp.length);
            pMove = pMove->next;
        }
        printf("\n");
    }
}

//在加减乘运算之后输出提示信息
void afterCal(Item *list,char *type){
    printf("%s的结果是:",type);
    outPut(list);
    printf("已经把结果存储 您可以继续进行其他运算\n");
}

//在多项式运算结束之后，销毁无用的多项式链表
void freeList(Item *list){
    Item *pMove = list->next;
    while(pMove!=NULL){
        free(list);
        list = pMove;
        pMove = pMove->next;
    }
    free(list);
}
