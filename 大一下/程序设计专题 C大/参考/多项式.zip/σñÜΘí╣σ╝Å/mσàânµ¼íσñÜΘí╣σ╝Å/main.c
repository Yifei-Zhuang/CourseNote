extern void menu(int);
extern void init();
int main(){
    int choice=0;
    init();
    menu(choice);
}
