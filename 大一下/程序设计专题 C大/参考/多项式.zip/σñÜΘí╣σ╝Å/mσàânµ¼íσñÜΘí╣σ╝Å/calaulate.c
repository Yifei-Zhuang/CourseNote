//
// Created by 庄毅非 on 2021/4/1.
//

#include"info.h"
extern void outPut(Item*);
extern void freeList(Item*);
extern void afterCal(Item*,char*);

//判断存储指数的大小，用在qsort中
int cmpExp(const void * a ,const void * b){
    return ((struct times *)a)->tar - ((struct times *)b)->tar;
}

//通过输入的两个次数多项式来判断其是否相等
int isEqual(struct expArray *a ,struct expArray *b){
    int len = b->length;
    if(a->length!=b->length) return 0;
//  输入的多项式可能不是按照下标输入的，因此这里先用qsort进行处理
    qsort(a->timesArray,len,sizeof(struct times),cmpExp);
    qsort(b->timesArray,len,sizeof(struct times),cmpExp);
    int i=0;
    while(i<len){
//      只有下标和次数都相等的两项才能是相同的两项
        if(!(a->timesArray[i].tar == b->timesArray[i].tar && a->timesArray[i].exp == b->timesArray[i].exp)) return 0;
        i++;
    }
    return 1;
}
//将值插入多项式
void insert(Item *list,int coef,struct times *varInfo,int length){
    Item *newNode = (Item *)malloc(sizeof(Item));
    newNode->coef = coef;
    newNode->exp.timesArray = varInfo;
    newNode->exp.length = length;
    newNode->next = NULL;
//  代表链表未输入,直接把新节点插在最后
    if(list->next == NULL){
        list->next = newNode;
        return;
    }
//  链表不为空，则查找是否有相同的节点
    else{
//      flag作为是否找到的标志
        int flag=0;
        Item *pre,*behind;
        pre = list;
        behind = list->next;
        while( flag == 0 && behind != NULL){
//            如果找到相等的节点，那么把系数相加即可，再另外处理系数为0的情况
            if(isEqual(&behind->exp,&newNode->exp)){
                behind->coef+=coef;
                if(behind->coef == 0){
                    pre->next = behind->next;
                    free(behind);
                }
                free(newNode);
                flag = 1;
            }
//          没有找到，搜索指针后移
            else{
                pre = behind;
                behind = behind->next;
            }
        }
        if (flag == 0)pre->next = newNode;
    }
}
//输入多项式 并返回虚头指针
Item *input(){
    Item *list=(Item *)malloc(sizeof(Item));
    list->next = NULL;
    int coe;
//  输出提示信息
    printf("每一项的输入格式是：系数 各个项的下标 对应次数(如果在某一项输入结束，那么请输入多项式的元数来停止该项的输入\n");
    printf("比如：输入1 0 1 2 2 3 5（假设元数是3，下标从0开始），对应的项是x0x2^2\n");
    printf("接下来,请输入第一项的系数\n");
    scanf("%d",&coe);
    while(coe!=0){
        printf("接下来输入该项各个非0元的下标和次数(要结束每一项的输入，请输入多项式的元数)\n");
        struct times *temp = malloc((degree+1)*sizeof(struct times));
        for(int i=0;i<degree+1;i++) temp[i].tar = -1;
        int len = 0;
        while(len<=degree){
            scanf("%d %d",&temp[len].tar,&temp[len].exp);
            if(temp[len].tar>degree){
                printf("你不能输入比元数更大的下标\n下标是从0开始\n");
                exit(0);
            }
            if(temp[len].tar == degree) break;
            len++;
        }
        insert(list,coe,temp,len);
        printf("请输入下一项的系数(为0则结束多项式的输入)\n");
//      清空缓冲区
        fflush(stdin);
        scanf("%d",&coe);
    }
    printf("输入结束，您输入的多项式是：");
    outPut(list);
    return list;
}

//进行多项式的减法
Item * subtract(Item *list){
    Item *tempHead = input();
    Item *temp = tempHead->next;
    while(temp!=NULL){
        insert(list,-temp->coef,temp->exp.timesArray,temp->exp.length);
        temp = temp->next;
    }
//   在运算结束之后，销毁原来的多项式，同时把结果输出
    freeList(tempHead);
    afterCal(list,"减法");
    return list;
}

//进行多项式的加法
Item *add(Item *list){
    Item *tempHead = input();
    Item *tempMove = tempHead->next;
    while(tempMove!=NULL){
        insert(list,tempMove->coef,tempMove->exp.timesArray,tempMove->exp.length);
        tempMove = tempMove->next;
    }
//   在运算结束之后，销毁原来的多项式，同时把结果输出
    freeList(tempHead);
    afterCal(list,"加法");
    return list;
}
//查找preNode中是否有该下标的项
struct times *find(struct times *x,struct times y,int length){
    for(int i=0;i<length;i++){
        if(y.tar == x[i].tar) return &x[i];
    }
    return NULL;
}
//模拟乘法，把两个项的对应下标的变量的次数相加，若无对应下标的变量就直接添加
struct times *conbineTwo(struct times* x,struct times *y,int *len1,int len2)
{
    int i=0;
    while(i<len2){
        struct times *negation = find(x,y[i],*len1);
//      为NULL说明没找到
        if(negation == NULL){
            x[*len1].tar = y[i].tar;
            x[*len1].exp = y[i].exp;
            (*len1)++;
        }
//      找到了，将系数相加
        else{
            negation->exp=negation->exp+y[i].exp;
        }
        i++;
    }
    return x;
}
//进行多项式的乘法
Item *multiply(Item *list){
//  res存储运算结果
    Item *res = (Item *)malloc(sizeof(Item));
    res->next = NULL;
    Item *preNode = list->next;
    Item *temp = input();
    Item *tempNode;
//  模拟乘法分配律
    while(preNode!=NULL) {
        tempNode = temp->next;
        while (tempNode != NULL) {
            struct times *tempArr=(struct times *)malloc(sizeof(struct times)*(degree+1));
            int tempSize = preNode->exp.length;
//          使用循环初始化tempArr
            for(int i=0;i<tempSize;i++){
                tempArr[i].tar = preNode->exp.timesArray[i].tar;
                tempArr[i].exp = preNode->exp.timesArray[i].exp;
            }
            for(int i = tempSize;i<degree+1;i++){
                tempArr[i].tar = -1;
            }
            struct times *conbine = conbineTwo(tempArr,tempNode->exp.timesArray,&tempSize,tempNode->exp.length);
            insert(res,preNode->coef*tempNode->coef,conbine,tempSize);
            tempNode = tempNode->next;
        }

        preNode = preNode->next;
    }
//   在运算结束之后，销毁原来的多项式，同时把结果输出
    freeList(temp);
    freeList(list);
    afterCal(res,"乘法");
    return res;
}
