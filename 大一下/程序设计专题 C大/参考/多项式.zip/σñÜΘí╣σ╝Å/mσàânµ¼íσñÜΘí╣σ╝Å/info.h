//
// Created by 庄毅非 on 2021/4/1.
//

#ifndef UNTITLED2_INFO_H
#define UNTITLED2_INFO_H
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
// 声明多项式的元数
int degree;
// 定义每一个节点内部的各个元的次数

struct times{
    int tar;
    int exp;
};

// 定义每一个节点的大小
struct expArray{
    struct times *timesArray;
    // 每一次输入 都把length加一
    int length;
};

// 一元多项式结构体定义
typedef struct item{
    int coef;
    struct expArray exp;
    struct item * next;
}Item;

//定义全局变量存储多项式（相当于计算器的记忆功能）
Item *head;

#endif //UNTITLED2_INFO_H
