#include<stdio.h>
#include<stdlib.h>
/*
使用pre来存储之前输入的多项式
使用temp来存储暂时输入的多项式
在使用运算符之后 更新pre的值
pre在用户界面呈现的是input标识
*/
// 一元多项式结构体定义
typedef struct item{
    int coef;
    int exp;
    struct item * next;
}Item;
void output(Item *head){
    if(head == NULL || head->next == NULL) printf("多项式为空");
    else{
        Item *pmove = head->next;
        printf("%dx^%d",pmove->coef,pmove->exp);
        pmove = pmove->next;
        while(pmove!=NULL){
            printf("+%dx^%d",pmove->coef,pmove->exp);
            pmove = pmove->next;
        }
        printf("\n");
    }
}
void insert(Item *head,int coef,int exp){
    Item * pmove = head;
    Item *newNode = (Item *)malloc(sizeof(Item));
    newNode->exp = exp;
    newNode->coef = coef;
    while(pmove->next!=NULL){
        if(pmove->exp>exp){
            newNode->next = pmove->next;
            pmove->next = newNode;
            return;
        }
        pmove = pmove->next;
    }
    pmove->next = newNode;
}
Item *input(){
    Item *newhead = (Item *)malloc(sizeof(Item));
    printf("请按照指数降序的方式将系数，指数输入，中间用空格分隔 当系数为0的时候输入结束\n");
    int coe,exp;
    scanf("%d %d",&coe,&exp);
    while(coe!=0){
        insert(newhead,coe,exp);
        scanf("%d %d",&coe,&exp);
    }
    printf("输入结束，您输入的多项式是：");
    output(newhead);
    return newhead;
}
Item *add(){
    Item *temp = input();
    


}
int main(){
    int choice;
    do{
        printf("程序菜单;\n 1-多项式输入;\n 2-多项式加(+);\n 3-多项式减(-);\n 4-多项式乘(*);\n 5多项式输出;\n 0-退出\n");
        fflush(stdin);
        scanf("%d",&choice);
        switch(choice){
            case 0:exit(0);
            case 1:input();
            // case 2:add();
            // case 3:subtract();
            // case 4:multiply();
            //  case 5:output();
        }
    }while(1);
    return 0;
}