#include "graphics.h"
#include "extgraph.h"
#include "genlib.h"
#include "simpio.h"
#include "random.h"
#include "strlib.h"
#include "conio.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stddef.h>

#include <windows.h>
#include <olectl.h>
#include <mmsystem.h>
#include <wingdi.h>
#include <ole2.h>
#include <ocidl.h>
#include <winuser.h>
#include<math.h>
//Ĭ����ɫ��ѡ����ɫ
#define defaultColor "red"
#define selectedColor "green"
//�ı���ز���
#define TEXTLEN 100
#define CURSOR "_"
#define CURSOR_BLINK  1     
const int timerseconds = 500; 
//ͼ��Ԫ�ؽṹ
typedef struct line{
    double x0,y0;
    double x1,y1;
    string color;
    struct line* next;
}*Line;
typedef struct rect{
    double x0,y0;
    double length,width;
    string color;
    struct rect* next;
}*Rect;
typedef struct ellipse{
    double x,y;
    double a,b;
    string color;
    struct ellipse* next;
}*ellipsePtr;
typedef struct Text{
	string text;
	double x, y;
	string color;
    int curPos; 
    bool isDisplayed;
    int penSize;
	struct Text *next;
} *TextT;
//�ж����Ҽ��Ƿ���
bool isDown = FALSE;
bool resizing = FALSE;
//�ж�ѡ��Ԫ�ص�����
int selectedType;
double minDistance[4] = {100000000,100000000,100000000,100000000};
//����ͷ�ڵ��ѡ��Ԫ�ؽڵ�
Line lineHead,minLine;
Rect rectHead,minRect;
ellipsePtr elliHead,minElli;
TextT textHead,minText;
//��ǰ�ı�ָ��
static TextT tptr;
//�ж��Ƿ����ı�����״̬
bool inText = FALSE;
//�жϹ���Ƿ�����˸
static bool isCursorBlink = FALSE;
void init();
void DrawAllElement();
void myDrawLine(Line cur);
bool LineEqual(Line a,Line b);
void myDrawRect(Rect cur);
bool RectEqual(Rect a,Rect b);
void myDrawElli(ellipsePtr cur);
bool ElliEqual(ellipsePtr a,ellipsePtr b);
void DrawTextT(void *text);
bool TextEqual(TextT a,TextT b);
void InsertCharToString(string str, int pos, char c);
void DeleteCharFromString(string str, int pos);
void DrawCursor(string str, int curPos, double startx, double starty);
void DeleteChar();
void KeyboardEventProcess(int key,int event);
void CharEventProcess(char c);
void MouseEventProcess(int x, int y, int button, int event);
void TimerEventProcess(int timerID);

void Main()

{
    
    InitGraphics();
    //InitConsole();
    SetPenColor("red");
	SetWindowTitle("CAD"); 
    Randomize();
    //printf("%lf",GetPenSize());
    registerKeyboardEvent(KeyboardEventProcess);
	registerCharEvent(CharEventProcess);
	registerMouseEvent(MouseEventProcess);
	registerTimerEvent(TimerEventProcess);
	init();
}
void init(){
    lineHead = GetBlock(sizeof(struct line));
    rectHead = GetBlock(sizeof(struct rect));
    elliHead = GetBlock(sizeof(struct ellipse));
    textHead = GetBlock(sizeof(struct Text));
    lineHead->next = NULL;
    rectHead->next = NULL;
    elliHead->next = NULL;
    textHead->next = NULL;
}
void KeyboardEventProcess(int key,int event){
    switch(event){
        case KEY_DOWN:
            switch(key){
                case VK_F1:{
                	//printf("1");
                    Line currentLine = GetBlock(sizeof(struct line));
                    //printf("%lf %lf",GetWindowWidth(),GetWindowHeight());
                    currentLine->x0 = RandomReal(1.0,GetWindowWidth()-1);
                    currentLine->y0 = RandomReal(1.0,GetWindowHeight()-1);
                    currentLine->x1 = RandomReal(1.0,GetWindowWidth()-1);
                    currentLine->y0 = RandomReal(1.0,GetWindowHeight()-1);
                    currentLine->next = NULL;
                    Line pMove = lineHead;
                    while(pMove->next) pMove = pMove->next;
                    pMove->next = currentLine;
                    currentLine->color = defaultColor;
                    myDrawLine(currentLine);

                    
                    //printf("2");
                    break;
                }
                case VK_F2:{
                    Rect currentRect = GetBlock(sizeof(struct rect));
                    currentRect->x0 = RandomReal(1.0,GetWindowWidth()-1);
                    currentRect->y0 = RandomReal(1.0,GetWindowHeight()-1);
                    currentRect->length = RandomReal(1.0,GetWindowWidth()-currentRect->x0);
                    currentRect->width = RandomReal(1.0,GetWindowHeight()-currentRect->y0);
                    currentRect->next = NULL;
                    Rect pMove = rectHead;
                    while(pMove->next) pMove = pMove->next;
                    pMove->next = currentRect;
                    currentRect->color = defaultColor;
                    myDrawRect(currentRect);
                    break;
                }
                case VK_F3:{
                    ellipsePtr currentElli =  GetBlock(sizeof(struct ellipse));
                    currentElli->x = RandomReal(0.0,GetWindowWidth()-1);
                    currentElli->y = RandomReal(0.0,GetWindowHeight()-1);
                    currentElli->a = RandomReal(0.0,GetWindowWidth()/2);
                    currentElli->b = RandomReal(0.0,GetWindowHeight()/2);
                    currentElli->next = NULL;
                    ellipsePtr pMove = elliHead;
                    while(pMove->next) pMove = pMove->next;
                    pMove->next = currentElli;
                    currentElli->color = defaultColor;
                    myDrawElli(currentElli);
                    break;
                }
                case VK_F4:{
                    if (inText) break;
					inText = TRUE; 
					tptr = GetBlock(sizeof(*tptr));
                    tptr->text = GetBlock(sizeof(char)*(TEXTLEN+1));
                    tptr->text[0]='\0';
					 tptr->x = RandomReal(0.0,GetWindowWidth()/2);
                     tptr->y = RandomReal(0.0,GetWindowHeight()-1);
                     tptr->curPos = 0; 
                     tptr->isDisplayed = TRUE; 
                    tptr->next = NULL;
                    MovePen(tptr->x, tptr->y);
	 	   			 DrawTextString(CURSOR);
                    startTimer(CURSOR_BLINK, timerseconds);
                    TextT pMove = textHead;
                    while(pMove->next) pMove = pMove->next;
                    pMove->next = tptr;
                    tptr->penSize=1;
                    tptr->color="green";
                    break;
                }
                case VK_LEFT:
                 	if (!inText) break;
                    SetEraseMode(TRUE);
					DrawCursor(tptr->text, tptr->curPos, tptr->x, tptr->y); 
                    if (tptr->curPos>0) tptr->curPos--;
                    SetEraseMode(FALSE);
					DrawCursor(tptr->text, tptr->curPos, tptr->x, tptr->y); 
					break;       
                case VK_RIGHT:
                 	if (!inText) break;
                    SetEraseMode(TRUE);
					DrawCursor(tptr->text, tptr->curPos, tptr->x, tptr->y); 
                    if (tptr->curPos<strlen(tptr->text)) tptr->curPos++;
                    SetEraseMode(FALSE);
					DrawCursor(tptr->text, tptr->curPos, tptr->x, tptr->y); 
				    break;   
                case VK_DELETE:
                    if(inText){
                        DeleteChar();
                    }
                    else{
                    	if(!isDown) return;
                        switch (selectedType){
                        	case 0:
                                if(minLine == NULL) break;
                                SetEraseMode(TRUE);
                                DrawAllElement();
                                SetEraseMode(FALSE);
                                findMinLine();
                        		Line tempLine = lineHead;
                        		//printf("1");
                                while(tempLine&&!LineEqual(tempLine->next,minLine)) tempLine = tempLine->next;
                                //printf("2");
                                tempLine->next = minLine->next;
                                FreeBlock(minLine);
                                minLine = NULL;
                                DrawAllElement();
                                minDistance[0] = 100000000;
                                isDown = FALSE;
                                break;
                            case 1:
                                if(minRect == NULL) break;
                                SetEraseMode(TRUE);
                                DrawAllElement();
                                SetEraseMode(FALSE);
                                //printf("0");
                        		Rect tempRect = rectHead;
                                //printf("1");
                                while(tempRect&&!RectEqual(tempRect->next,minRect)) tempRect = tempRect->next;
                                //printf("2");
                                tempRect->next = minRect->next;
                                //printf("5");
                                FreeBlock(minRect);
                                minRect = NULL;
                                DrawAllElement();
                                minDistance[1] = 100000000;
                                isDown = FALSE;
                                break;
                            case 2:
                                if(minElli == NULL) break;
                                SetEraseMode(TRUE);
                                DrawAllElement();
                                SetEraseMode(FALSE);
                        		ellipsePtr tempElli = elliHead;
                                while(tempElli&&!ElliEqual(tempElli->next,minElli)) tempElli = tempElli->next;
                                tempElli->next = minElli->next;
                                FreeBlock(minElli);
                                minElli = NULL;
                                DrawAllElement();
                                minDistance[2] = 100000000;
                                isDown = FALSE;
                            	break;
							case 3:
								if(minText == NULL) break;
                                SetEraseMode(TRUE);
                                DrawAllElement();
                                SetEraseMode(FALSE);
                        		TextT tempText = textHead;
                                while(tempText&&!TextEqual(tempText->next,minText)) tempText = tempText->next;
                                tempText->next = minText->next;
                                FreeBlock(minText);
                                minText = NULL;
                                DrawAllElement();
                                minDistance[3] = 100000000;
                                isDown = FALSE;
                            	break;
                            default:
                                break;
                        }
                    }
                    break;
                default:
                    break;
            }
            break;

    }
}
void MouseEventProcess(int x, int y, int button, int event){
    double mx, my;
    double dx, dy;
    static double omx = 0.0, omy = 0.0;
    mx = ScaleXInches(x);
    my = ScaleYInches(y);
    switch (event) {
            case BUTTON_DOWN:
            	if(inText) break;
                if (button == LEFT_BUTTON) { 
                    findNode(mx,my);
                    //printf("yes");
                    omx = mx;
                    omy = my;
                    isDown = TRUE;
                }
                else if(button == RIGHT_BUTTON){
                    findNode(mx,my);
                    omx = mx;
                    omy = my;
                    resizing = TRUE;
                }
                break; 
            case BUTTON_DOUBLECLICK:
                break;
            case BUTTON_UP:
                if(resizing){
                SetPenColor(defaultColor);
                switch(selectedType){
                    case 0:
                    	minLine->color=defaultColor;
                        myDrawLine(minLine);
                        break;
                    case 1:
                    	minRect->color=defaultColor;
                        myDrawRect(minRect);
                        break;
                    case 2:
                    	minElli->color=defaultColor;
                        myDrawElli(minElli);
                        break;

                    default:
                        break;
                }
                resizing = FALSE; 

                }
                break;
            case MOUSEMOVE:{
                if(!isDown&&!resizing) break;
                switch(selectedType){
                    case 0:{
                        if(minLine == NULL) break;
                        dx = mx-omx;
                        dy = my-omy;
                        SetEraseMode(TRUE);
                        DrawAllElement();
                        SetEraseMode(FALSE);
                        minLine->color = selectedColor;
                        if(isDown){
                        minLine->x0+=dx;
                        minLine->x1+=dx;
                        minLine->y0+=dy;
                        minLine->y1+=dy;
                        }
                        else{
                            minLine->x1+=dx;
                            minLine->y1+=dy;
                        }
                        DrawAllElement();
                        omx = mx;
                        omy = my;		
                        break;
                    }
                    case 1:{
                        if(minRect == NULL) break;
                    	dx = mx-omx;
                        dy = my-omy;
                        SetEraseMode(TRUE);
                        DrawAllElement();
                        SetEraseMode(FALSE);
                        minRect->color = selectedColor;
                        if(isDown){
                        minRect->x0+=dx;
                        minRect->y0+=dy;
                        }
                        else{
                            minRect->length+=dx;
                            minRect->width+=dy;
                        }
                        DrawAllElement();
                        omx = mx;
                        omy = my;
                        break;
                    }
                    case 2:{
                        if(minElli == NULL) break;
                        dx = mx-omx;
                        dy = my-omy;
                        SetEraseMode(TRUE);
                        DrawAllElement();
                        SetEraseMode(FALSE);
                        minElli->color = selectedColor;
                        if(isDown){
                        minElli->x+=dx;
                        minElli->y+=dy;
                        }
                        else{
                            minElli->a+=dx;
                            minElli->b+=dy;
                        }
                        DrawAllElement();
                        omx = mx;
                        omy = my;
                        break;
                    }
                    case 3:{
                        if(minText == NULL) break;
                        dx = mx-omx;
                        dy = my-omy;
                        tptr=minText;
                        SetEraseMode(TRUE);
                        DrawAllElement();
                        SetEraseMode(FALSE);
                        //printf("yes2");
                        minText->color = selectedColor;
                        if(isDown){
                        minText->x+=dx;
                        minText->y+=dy;

                        }
//                        else{
//                            minText->penSize+=dx/0.1;
//                        }
                        DrawAllElement();
                        omx = mx;
                        omy = my;
                        break;
                    }
                    default:
                        break;
                }
                
            }
            default:
            break;
    } 
}

void CharEventProcess(char c){
    int len;
        switch (c) {
            case 27:
            case '\r':
                if(isDown){
                SetPenColor(defaultColor);
                switch(selectedType){
                    case 0:
                    	minLine->color=defaultColor;
                        myDrawLine(minLine);
                        break;
                    case 1:
                    	minRect->color=defaultColor;
                        myDrawRect(minRect);
                        break;
                    case 2:
                    	minElli->color=defaultColor;
                        myDrawElli(minElli);
                        break;
                    default:
                        break;
                    }
                isDown = FALSE; 
                }
                else if(inText){
				tptr->color = "red";
				SetPenColor("red");
                inText = FALSE;
                SetEraseMode(TRUE);
                DrawCursor(tptr->text, tptr->curPos, tptr->x, tptr->y);
				DrawAllElement();                
                tptr->isDisplayed = FALSE;

                SetEraseMode(FALSE);
                cancelTimer(CURSOR_BLINK);
                isCursorBlink = FALSE;
                DrawAllElement();
                SetPenSize(1);
				}
                break;
            
            case '\b':
            	if(inText){
                DeleteChar();
            }
                break;
            default:{
            	if(inText){
                SetPenSize(tptr->penSize);
                if ((len = strlen(tptr->text)) >= TEXTLEN) break; 
                SetEraseMode(TRUE);
                MovePen(tptr->x, tptr->y);
                DrawTextString(tptr->text);
                DrawCursor(tptr->text, tptr->curPos, tptr->x, tptr->y);
                InsertCharToString(tptr->text, tptr->curPos, c);
                SetEraseMode(FALSE);
                MovePen(tptr->x, tptr->y);
                DrawTextString(tptr->text);
                tptr->curPos++; 
                DrawCursor(tptr->text, tptr->curPos, tptr->x, tptr->y);
                break;
            }
        }
    }
}
void TimerEventProcess(int timerID){
    switch (timerID) {
        case CURSOR_BLINK:
			SetEraseMode(!tptr->isDisplayed);
			DrawCursor(tptr->text, tptr->curPos, tptr->x, tptr->y);
			SetEraseMode(FALSE);
			MovePen(tptr->x, tptr->y);
			DrawTextString(tptr->text);
			tptr->isDisplayed=!tptr->isDisplayed;
			break;
        default:
            break;
    }
}

//ֱ����غ���
bool LineEqual(Line a,Line b){
    if(a==NULL) return FALSE;
    return a->x0 == b->x0 && a->x1 == b->x1 && a->y0 == b->y0 && a->y1 == b->y1;
}

void findMinLine(double mx,double my){
    Line temp = lineHead->next;
    if(temp == NULL) return NULL;
    double mindistance = 100000000;
    while(temp!=NULL){
        double curdistance = (((mx-temp->x0)*(temp->x1-temp->x0))+(my-temp->y0)*(temp->y1 - temp->y0))/sqrt(pow(temp->y0-temp->y1,2)+pow(temp->x0-temp->x1,2));
        curdistance = abs(curdistance);
        if(curdistance<mindistance) {
            mindistance = curdistance;
            minLine = temp;
        }
        temp = temp->next;
    }
    minDistance[0] = mindistance;
}
void myDrawLine(Line cur){
    MovePen(cur->x0,cur->y0);
    DrawLine(cur->x1-cur->x0,cur->y1-cur->y0);
}

//������غ���
bool RectEqual(Rect a,Rect b){
    if(a==NULL) return FALSE;
    
    return a->length == b->length && a->width == b->width && a->x0 == b->x0 && a->y0 == b->y0;
}
void findMinRect(double mx,double my){
    Rect temp = rectHead->next;
    if(temp == NULL) return NULL;
    double mindistance = 100000000;
    while(temp!=NULL){
        double curdistance = sqrt(pow(mx-(temp->x0+temp->length/2),2)+pow(my-(temp->y0+temp->width/2),2));
        if(curdistance<mindistance) {
            mindistance = curdistance;
            minRect = temp;
        }
        temp = temp->next;
    }
    minDistance[1] = mindistance;
}
//��Բ��غ���
bool ElliEqual(ellipsePtr a,ellipsePtr b){
    if(a==NULL) return FALSE;
    return a->x == b->x && a->y == b->y && a->a == b->a && a->b == b->b;
}
void findMinElli(double mx,double my){
    ellipsePtr temp = elliHead->next;
    if(temp == NULL) return NULL;
    double mindistance = 100000000;

    while(temp!=NULL){
        double curdistance = sqrt(pow(mx-temp->x+(temp->a-temp->b)/2,2)+pow(my-temp->y,2));
        if(curdistance<mindistance) {
            mindistance = curdistance;
            minElli = temp;
        }
        temp = temp->next;
        
    }
    minDistance[2] = mindistance;
}

void myDrawRect(Rect cur){
    MovePen(cur->x0,cur->y0);
    DrawLine(cur->length,0);
    DrawLine(0,cur->width);
    DrawLine(-cur->length,0);
    DrawLine(0,-cur->width);
}

//�ı���غ���
void DrawTextT(void *text)
{
	TextT tptr = (TextT)text;
	MovePen(tptr->x, tptr->y);
    DrawTextString(tptr->text);
}

void DrawCursor(string str, int curPos, double startx, double starty)
{
	if (curPos < 0 || curPos > strlen(str)) return;
	MovePen(startx+TextStringWidth(SubString(str, 0, curPos-1)), starty);
	DrawTextString(CURSOR);
	return;
}
 
void InsertCharToString(string str, int pos, char c)
{
	int len;
	
	if (pos < 0 || pos >= TEXTLEN) return;
	len = strlen(str);
	*(str+len+1) = '\0';
	while (len > pos) {
		*(str+len) = *(str+len-1);
		len--;
	}	
	*(str+len) = c;
	return;
}

void DeleteCharFromString(string str, int pos)
{
	int len;
	
	len = strlen(str);
	if (pos < 0 || pos >= len) return;
	
	while (*(str+pos) != '\0') {
		*(str+pos) = *(str+pos+1);
		pos++; 
	}
	return;
}


void DeleteChar(){
    int len;
    if ((len = strlen(tptr->text)) == 0) return;
    SetEraseMode(TRUE);
    MovePen(tptr->x, tptr->y);
    DrawTextString(tptr->text);
    DrawCursor(tptr->text, tptr->curPos, tptr->x, tptr->y);
    DeleteCharFromString(tptr->text, tptr->curPos-1);
    SetEraseMode(FALSE);
    MovePen(tptr->x, tptr->y);
    DrawTextString(tptr->text);
    if (tptr->curPos > 0) tptr->curPos--;
    DrawCursor(tptr->text, tptr->curPos, tptr->x, tptr->y);
}


void myDrawElli(ellipsePtr cur){
    MovePen(cur->x + cur->a, cur->y);
    DrawEllipticalArc(cur->a, cur->b, 0.0, 360.0);
}
bool TextEqual(TextT a,TextT b){
    if(a==NULL) return FALSE;
	return a->x == b->x && a->y == b->y && StringCompare(a->text,b->text) == 0;
}
void findMinText(double mx,double my){
    TextT temp = textHead->next;
    if(temp == NULL) return NULL;
    double mindistance = 100000000;
    while(temp!=NULL){
        double curdistance = sqrt(pow(mx-temp->x,2)+pow(my-temp->y,2));
        if(curdistance<mindistance) {
            mindistance = curdistance;
            minText = temp;
        }

        temp = temp->next;
    }
    minDistance[3] = mindistance;
}
//ͨ�ú���
void findNode(double mx,double my){
    findMinLine(mx,my);
    findMinRect(mx,my);
    findMinElli(mx,my);
    findMinText(mx,my);
    int min=0,move=1;
    while(move<4){
        if(minDistance[move]<minDistance[min]) min = move; 
        move++;
    }
    selectedType = min;
}


void DrawAllElement(){
    SetPenColor(defaultColor);
	Line tempLine = lineHead->next;
	while(tempLine){
		SetPenColor(tempLine->color);
        myDrawLine(tempLine);
        tempLine = tempLine->next;
	}
    Rect tempRect = rectHead->next;
    while(tempRect){
    	SetPenColor(tempRect->color);
        myDrawRect(tempRect);
        tempRect = tempRect->next;
    }
    ellipsePtr tempElli = elliHead->next;
    while(tempElli){
    	SetPenColor(tempElli->color);
        myDrawElli(tempElli);
        tempElli=tempElli->next;
    }
    TextT tempText = textHead->next;
    while(tempText){
        SetPenColor(tempText->color);
        SetPenSize(tempText->penSize);
        MovePen(tempText->x,tempText->y);
        DrawTextString(tempText->text);
        tempText = tempText->next;
    }
    SetPenSize(1);
    SetPenColor(defaultColor);
}
