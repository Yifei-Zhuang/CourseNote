/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "//vmware-host/Shared Folders/win/submit/final_proj/project/ButtonCheck.v";
static unsigned int ng1[] = {0U, 0U};
static unsigned int ng2[] = {1U, 0U};
static int ng3[] = {0, 0};
static int ng4[] = {1, 0};
static int ng5[] = {2, 0};
static int ng6[] = {3, 0};



static void Always_28_0(char *t0)
{
    char t4[8];
    char t5[8];
    char t8[8];
    char t34[8];
    char *t1;
    char *t2;
    char *t3;
    char *t6;
    char *t7;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    char *t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    char *t22;
    char *t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    char *t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    char *t32;
    char *t33;
    char *t35;
    char *t36;
    char *t37;
    char *t38;
    char *t39;
    unsigned int t40;
    int t41;

LAB0:    t1 = (t0 + 2368U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(28, ng0);
    t2 = (t0 + 2688);
    *((int *)t2) = 1;
    t3 = (t0 + 2400);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(28, ng0);

LAB5:    xsi_set_current_line(29, ng0);
    t6 = (t0 + 1048U);
    t7 = *((char **)t6);
    memset(t8, 0, 8);
    t6 = (t8 + 4);
    t9 = (t7 + 4);
    t10 = *((unsigned int *)t7);
    t11 = (t10 >> 0);
    t12 = (t11 & 1);
    *((unsigned int *)t8) = t12;
    t13 = *((unsigned int *)t9);
    t14 = (t13 >> 0);
    t15 = (t14 & 1);
    *((unsigned int *)t6) = t15;
    memset(t5, 0, 8);
    t16 = (t8 + 4);
    t17 = *((unsigned int *)t16);
    t18 = (~(t17));
    t19 = *((unsigned int *)t8);
    t20 = (t19 & t18);
    t21 = (t20 & 1U);
    if (t21 != 0)
        goto LAB6;

LAB7:    if (*((unsigned int *)t16) != 0)
        goto LAB8;

LAB9:    t23 = (t5 + 4);
    t24 = *((unsigned int *)t5);
    t25 = *((unsigned int *)t23);
    t26 = (t24 || t25);
    if (t26 > 0)
        goto LAB10;

LAB11:    t28 = *((unsigned int *)t5);
    t29 = (~(t28));
    t30 = *((unsigned int *)t23);
    t31 = (t29 || t30);
    if (t31 > 0)
        goto LAB12;

LAB13:    if (*((unsigned int *)t23) > 0)
        goto LAB14;

LAB15:    if (*((unsigned int *)t5) > 0)
        goto LAB16;

LAB17:    memcpy(t4, t32, 8);

LAB18:    t33 = (t0 + 1448);
    t35 = (t0 + 1448);
    t36 = (t35 + 72U);
    t37 = *((char **)t36);
    t38 = ((char*)((ng3)));
    xsi_vlog_generic_convert_bit_index(t34, t37, 2, t38, 32, 1);
    t39 = (t34 + 4);
    t40 = *((unsigned int *)t39);
    t41 = (!(t40));
    if (t41 == 1)
        goto LAB19;

LAB20:    xsi_set_current_line(30, ng0);
    t2 = (t0 + 1048U);
    t3 = *((char **)t2);
    memset(t8, 0, 8);
    t2 = (t8 + 4);
    t6 = (t3 + 4);
    t10 = *((unsigned int *)t3);
    t11 = (t10 >> 1);
    t12 = (t11 & 1);
    *((unsigned int *)t8) = t12;
    t13 = *((unsigned int *)t6);
    t14 = (t13 >> 1);
    t15 = (t14 & 1);
    *((unsigned int *)t2) = t15;
    memset(t5, 0, 8);
    t7 = (t8 + 4);
    t17 = *((unsigned int *)t7);
    t18 = (~(t17));
    t19 = *((unsigned int *)t8);
    t20 = (t19 & t18);
    t21 = (t20 & 1U);
    if (t21 != 0)
        goto LAB21;

LAB22:    if (*((unsigned int *)t7) != 0)
        goto LAB23;

LAB24:    t16 = (t5 + 4);
    t24 = *((unsigned int *)t5);
    t25 = *((unsigned int *)t16);
    t26 = (t24 || t25);
    if (t26 > 0)
        goto LAB25;

LAB26:    t28 = *((unsigned int *)t5);
    t29 = (~(t28));
    t30 = *((unsigned int *)t16);
    t31 = (t29 || t30);
    if (t31 > 0)
        goto LAB27;

LAB28:    if (*((unsigned int *)t16) > 0)
        goto LAB29;

LAB30:    if (*((unsigned int *)t5) > 0)
        goto LAB31;

LAB32:    memcpy(t4, t23, 8);

LAB33:    t27 = (t0 + 1448);
    t32 = (t0 + 1448);
    t33 = (t32 + 72U);
    t35 = *((char **)t33);
    t36 = ((char*)((ng4)));
    xsi_vlog_generic_convert_bit_index(t34, t35, 2, t36, 32, 1);
    t37 = (t34 + 4);
    t40 = *((unsigned int *)t37);
    t41 = (!(t40));
    if (t41 == 1)
        goto LAB34;

LAB35:    xsi_set_current_line(31, ng0);
    t2 = (t0 + 1048U);
    t3 = *((char **)t2);
    memset(t8, 0, 8);
    t2 = (t8 + 4);
    t6 = (t3 + 4);
    t10 = *((unsigned int *)t3);
    t11 = (t10 >> 2);
    t12 = (t11 & 1);
    *((unsigned int *)t8) = t12;
    t13 = *((unsigned int *)t6);
    t14 = (t13 >> 2);
    t15 = (t14 & 1);
    *((unsigned int *)t2) = t15;
    memset(t5, 0, 8);
    t7 = (t8 + 4);
    t17 = *((unsigned int *)t7);
    t18 = (~(t17));
    t19 = *((unsigned int *)t8);
    t20 = (t19 & t18);
    t21 = (t20 & 1U);
    if (t21 != 0)
        goto LAB36;

LAB37:    if (*((unsigned int *)t7) != 0)
        goto LAB38;

LAB39:    t16 = (t5 + 4);
    t24 = *((unsigned int *)t5);
    t25 = *((unsigned int *)t16);
    t26 = (t24 || t25);
    if (t26 > 0)
        goto LAB40;

LAB41:    t28 = *((unsigned int *)t5);
    t29 = (~(t28));
    t30 = *((unsigned int *)t16);
    t31 = (t29 || t30);
    if (t31 > 0)
        goto LAB42;

LAB43:    if (*((unsigned int *)t16) > 0)
        goto LAB44;

LAB45:    if (*((unsigned int *)t5) > 0)
        goto LAB46;

LAB47:    memcpy(t4, t23, 8);

LAB48:    t27 = (t0 + 1448);
    t32 = (t0 + 1448);
    t33 = (t32 + 72U);
    t35 = *((char **)t33);
    t36 = ((char*)((ng5)));
    xsi_vlog_generic_convert_bit_index(t34, t35, 2, t36, 32, 1);
    t37 = (t34 + 4);
    t40 = *((unsigned int *)t37);
    t41 = (!(t40));
    if (t41 == 1)
        goto LAB49;

LAB50:    xsi_set_current_line(32, ng0);
    t2 = (t0 + 1048U);
    t3 = *((char **)t2);
    memset(t8, 0, 8);
    t2 = (t8 + 4);
    t6 = (t3 + 4);
    t10 = *((unsigned int *)t3);
    t11 = (t10 >> 3);
    t12 = (t11 & 1);
    *((unsigned int *)t8) = t12;
    t13 = *((unsigned int *)t6);
    t14 = (t13 >> 3);
    t15 = (t14 & 1);
    *((unsigned int *)t2) = t15;
    memset(t5, 0, 8);
    t7 = (t8 + 4);
    t17 = *((unsigned int *)t7);
    t18 = (~(t17));
    t19 = *((unsigned int *)t8);
    t20 = (t19 & t18);
    t21 = (t20 & 1U);
    if (t21 != 0)
        goto LAB51;

LAB52:    if (*((unsigned int *)t7) != 0)
        goto LAB53;

LAB54:    t16 = (t5 + 4);
    t24 = *((unsigned int *)t5);
    t25 = *((unsigned int *)t16);
    t26 = (t24 || t25);
    if (t26 > 0)
        goto LAB55;

LAB56:    t28 = *((unsigned int *)t5);
    t29 = (~(t28));
    t30 = *((unsigned int *)t16);
    t31 = (t29 || t30);
    if (t31 > 0)
        goto LAB57;

LAB58:    if (*((unsigned int *)t16) > 0)
        goto LAB59;

LAB60:    if (*((unsigned int *)t5) > 0)
        goto LAB61;

LAB62:    memcpy(t4, t23, 8);

LAB63:    t27 = (t0 + 1448);
    t32 = (t0 + 1448);
    t33 = (t32 + 72U);
    t35 = *((char **)t33);
    t36 = ((char*)((ng6)));
    xsi_vlog_generic_convert_bit_index(t34, t35, 2, t36, 32, 1);
    t37 = (t34 + 4);
    t40 = *((unsigned int *)t37);
    t41 = (!(t40));
    if (t41 == 1)
        goto LAB64;

LAB65:    goto LAB2;

LAB6:    *((unsigned int *)t5) = 1;
    goto LAB9;

LAB8:    t22 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t22) = 1;
    goto LAB9;

LAB10:    t27 = ((char*)((ng1)));
    goto LAB11;

LAB12:    t32 = ((char*)((ng2)));
    goto LAB13;

LAB14:    xsi_vlog_unsigned_bit_combine(t4, 1, t27, 1, t32, 1);
    goto LAB18;

LAB16:    memcpy(t4, t27, 8);
    goto LAB18;

LAB19:    xsi_vlogvar_assign_value(t33, t4, 0, *((unsigned int *)t34), 1);
    goto LAB20;

LAB21:    *((unsigned int *)t5) = 1;
    goto LAB24;

LAB23:    t9 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t9) = 1;
    goto LAB24;

LAB25:    t22 = ((char*)((ng1)));
    goto LAB26;

LAB27:    t23 = ((char*)((ng2)));
    goto LAB28;

LAB29:    xsi_vlog_unsigned_bit_combine(t4, 1, t22, 1, t23, 1);
    goto LAB33;

LAB31:    memcpy(t4, t22, 8);
    goto LAB33;

LAB34:    xsi_vlogvar_assign_value(t27, t4, 0, *((unsigned int *)t34), 1);
    goto LAB35;

LAB36:    *((unsigned int *)t5) = 1;
    goto LAB39;

LAB38:    t9 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t9) = 1;
    goto LAB39;

LAB40:    t22 = ((char*)((ng1)));
    goto LAB41;

LAB42:    t23 = ((char*)((ng2)));
    goto LAB43;

LAB44:    xsi_vlog_unsigned_bit_combine(t4, 1, t22, 1, t23, 1);
    goto LAB48;

LAB46:    memcpy(t4, t22, 8);
    goto LAB48;

LAB49:    xsi_vlogvar_assign_value(t27, t4, 0, *((unsigned int *)t34), 1);
    goto LAB50;

LAB51:    *((unsigned int *)t5) = 1;
    goto LAB54;

LAB53:    t9 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t9) = 1;
    goto LAB54;

LAB55:    t22 = ((char*)((ng1)));
    goto LAB56;

LAB57:    t23 = ((char*)((ng2)));
    goto LAB58;

LAB59:    xsi_vlog_unsigned_bit_combine(t4, 1, t22, 1, t23, 1);
    goto LAB63;

LAB61:    memcpy(t4, t22, 8);
    goto LAB63;

LAB64:    xsi_vlogvar_assign_value(t27, t4, 0, *((unsigned int *)t34), 1);
    goto LAB65;

}


extern void work_m_00000000001246178316_1281180201_init()
{
	static char *pe[] = {(void *)Always_28_0};
	xsi_register_didat("work_m_00000000001246178316_1281180201", "isim/ButtonCheck_isim_beh.exe.sim/work/m_00000000001246178316_1281180201.didat");
	xsi_register_executes(pe);
}
